<?php 
/*
 *  vim:ts=4:expandtab:cindent
 *  This file is part of Urd.
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2013-06-28 23:30:22 +0200 (vr, 28 jun 2013) $
 * $Rev: 2852 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: ajax_showstatus.php 2852 2013-06-28 21:30:22Z gavinspearhead@gmail.com $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);
$__auth = 'silent';

$pathajss = realpath(dirname(__FILE__));

require_once "$pathajss/../functions/ajax_includes.php"; 

$root_prefs = load_config($db);

$startup_perc = $root_prefs['urdd_startup'];
$type = get_request('type', 'normal');

if (!in_array($type, array('quick', 'disk', 'activity', 'icon'))) {
    die_html('Missing type');
}


// First: Basic stats.
// can we connect?
try {
    $uc = new urdd_client($db, $root_prefs['urdd_host'], $root_prefs['urdd_port'], $userID);
    $isconnected = $uc->is_connected();
} catch (exception $e) {
    $isconnected = FALSE;
}
init_smarty('', 0);
if ($type == 'quick' || $type == 'icon') {
    $counter = 0;
    if ($isconnected) {
        $sql = 'count("ID") as "counter" FROM queueinfo WHERE "status" = \''. QUEUE_RUNNING .'\'' ;
        $res = $db->select_query($sql); 
        $counter = isset($res[0]['counter']) ? $res[0]['counter']: 0;
    } 
    $smarty->assign('counter',		$counter);

} elseif ($type == 'disk') {
    if ($isconnected) {
        $diskspace = $uc->diskfree('h');
        $disk_perc = $uc->diskfree('p1');
        $nodisk_perc = 100 - (int) $disk_perc;

        $smarty->assign('diskfree',		    $diskspace[0] . ' ' .$diskspace[1]);
        $smarty->assign('diskused',		    $diskspace[2] . ' ' .$diskspace[3]);
        $smarty->assign('disk_perc',		$disk_perc);
        $smarty->assign('nodisk_perc',		$nodisk_perc);
    }

} elseif ($type == 'activity') {
    $tasks = array();
    if ($isconnected) {
        // Second: Current jobs.
        $sql = '"description", max("progress") AS "progress", min("ETA") as "ETA", min("command_id") AS "command_id", count("ID") as "counter" FROM queueinfo WHERE "status" = \''. QUEUE_RUNNING .'\' GROUP BY "description"'; 
        $res = $db->select_query($sql); 
        if ($res === FALSE) { 
            $res = array();
        }

        foreach ($res as $row) {
            $description = $row['description'];
            $db->escape($description, TRUE);
            $task = command_description($db, $row['description']);
            $sql = "min(\"ETA\") AS \"ETA\" FROM queueinfo WHERE \"description\" LIKE $description AND \"ETA\" > 0 ";
            $res2 = $db->select_query($sql); 
            $ETA = isset($res2[0]['ETA']) ? $res2[0]['ETA'] : '';
            $row['task'] = $task[0];
            $row['args'] = $task[1];
            $row['type'] = $task[3];
            $dlid = $task[2];
            $progress = $row['progress'] = min(100, $row['progress']);
            $command_id = $row['command_id'];

            // We're gonna use $row as the array containing all data:
            $row['niceeta'] = -1;
            $row['target'] = '';

            if ($progress < 100 && $ETA != 0) {
                $row['niceeta'] = readable_time($ETA, 'fancy');
            }

            // Uniquify:
            $arrayid = $row['task'] . $row['args'] . $dlid;

            // $tasks are previously added items, $row is current item.
            // If there's a previous item, it might be merged with this one if they are identical.

            // Create or Overwrite the item:
            $tasks[$arrayid] = $row;
        }
        $cnt = count($tasks);
        $smarty->assign('tasks',		    $tasks);
        $smarty->assign('counter',	    	$cnt);
    }
}

$uc->disconnect();
$smarty->assign('startup_perc',	    $startup_perc);
$smarty->assign('isconnected',		$isconnected);
$smarty->assign('isadmin',	    	$isadmin);
$smarty->assign('type',	$type);
$smarty->display('ajax_showstatus.tpl');

