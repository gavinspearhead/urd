<?php
/**
 *  This file is part of Urd.
 *  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2013-06-28 23:30:22 +0200 (vr, 28 jun 2013) $
 * $Rev: 2852 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: admin_config.php 2852 2013-06-28 21:30:22Z gavinspearhead@gmail.com $
 */

define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);


$pathadc = realpath(dirname(__FILE__));

require_once "$pathadc/../functions/html_includes.php";
require_once "$pathadc/../functions/pref_functions.php";
require_once "$pathadc/../functions/periods.php";
require_once "$pathadc/../urdd/urdd_test.php";

verify_access($db, NULL, TRUE, '', $userID, FALSE);


$add_menu = array (
    'actions'=> 
    array(
        new menu_item2('import_config', 'settings_import', urd_modules::URD_CLASS_GENERIC, '', 'command'),
        new menu_item2('export_config', 'settings_export', urd_modules::URD_CLASS_GENERIC, '', 'command'),
        new menu_item2('reset_config', 'reset', urd_modules::URD_CLASS_GENERIC, $LN['reset'] . ' ' . $LN['config_title'], 'command'),
    )
);

update_settings($db, user_status::SUPER_USERID);

$cmd = get_post('cmd', '');

$imported = $saved = 0;

$on_off = array(
    'on'    => $LN['on'], 
    'off'   => $LN['off']
);

$cleandir_dirs = array(
    'all'       => $LN['all'], 
    'preview'   => $LN['preview'], 
    'tmp'       => $LN['temporary']
);

try {
    $groups_orig = read_system_groups();
} catch(exception$e) {
    $__message[] = $e->getMessage();
    $groups_orig = array();
}

$all_users = get_all_users($db);
$stylesheets = get_stylesheets();
$mail_templates = get_mail_templates();

sort($groups_orig);
$groups[''] = '';
foreach ($groups_orig as $g) {
    $groups["$g"] = $g;
}

$users[''] = $LN['disabled'];
foreach ($all_users as $u) {
    $users[$u] = $u;
}

$pref_level = get_request('pref_level', '');
$levels = user_levels::get_user_levels();
if (!in_array($pref_level, array_keys($levels))) {
    $pref_level = '';
}
if ($pref_level == '') {
    $pref_level = get_pref($db, 'pref_level', $userID);
} else {
    // this is a preference not a config setting
    $pref_level_msg = set_and_test_pref_array('pref_level', $userID, array_keys($levels));
}

$permissions = array(
    ''     => $LN['config_perms']['none'], 
    '0400' => $LN['config_perms']['0400'], 
    '0600' => $LN['config_perms']['0600'], 
    '0640' => $LN['config_perms']['0640'], 
    '0644' => $LN['config_perms']['0644'], 
    '0660' => $LN['config_perms']['0660'], 
    '0664' => $LN['config_perms']['0664'], 
    '0666' => $LN['config_perms']['0666']
);

$templates = get_templates();
$languages = get_languages();

$log_levels = array();
$rprefs = load_config($db);

foreach ($log_str as $level => $log) {
    $log_levels[$level] = ucwords($log);
}

try {
    $searchbuttons = get_buttons($db);
} catch (exception $e) {
    $searchbuttons = array();
}

$follow_link_msg = $shaping_msg = $auto_expire_msg = $urdd_restart_msg = $nntp_useauth_msg = $auto_reg_msg = $register_msg = $hiddenfiles_msg = $urdd_daemonise_msg = '';
$sendmail_msg = $webdownload_msg = $auto_download_msg = $check_nntp_connections_msg = $user_scripts_msg = $global_scripts_msg = $download_spots_comments_msg = $download_spots_reports_msg = '';
$parse_nfo_msg = $keep_int_msg = $compress_nzb_msg = $webeditfile_msg = $config_viewfiles_msg = $auto_getnfo_msg = $allow_robots_msg = $clickjack_msg = $download_spots_images_msg = '';
$config_groups_msg = $config_makenzb_msg = $config_usenzb_msg = $config_post_msg = $config_rss_msg = $config_sync_msg = $config_download_msg = '';

$module_msg = array(
    urd_modules::URD_CLASS_GENERIC      => '', 
    urd_modules::URD_CLASS_GROUPS       => '', 
    urd_modules::URD_CLASS_USENZB       => '', 
    urd_modules::URD_CLASS_MAKENZB      => '', 
    urd_modules::URD_CLASS_RSS          => '', 
    urd_modules::URD_CLASS_SYNC         => '', 
    urd_modules::URD_CLASS_SPOTS        => '', 
    urd_modules::URD_CLASS_DOWNLOAD     => '', 
    urd_modules::URD_CLASS_VIEWFILES    => '', 
    urd_modules::URD_CLASS_POST         => ''
);

$index_page_array = get_index_page_array($isadmin, urd_modules::get_urd_module_config(get_config($db, 'modules')));
// URDD online?
$uc = new urdd_client($db, $rprefs['urdd_host'], $rprefs['urdd_port'], $userID);
$URDDONLINE = $uc->is_connected();

if ($cmd == 'save_settings') {
    export_settings($db, 'config', 'urd_config.xml');
}

if ($cmd == 'load_settings') {
    challenge::verify_challenge($_POST['challenge']);
    $xml = new urd_xml_reader($_FILES['filename']['tmp_name']);
    $settings = $xml->read_config($db);
    if ($settings != array()) {
        clean_config($db);
        reset_config($db);
        set_configs($db, $settings);
        $imported = 1;
    } else {
        $__message[] = $LN['settings_notfound'];
    }
}


function update_periodic(DatabaseConnection $db, $name, $command, urdd_client $uc, $pkeys, $par1='', $par2= '', $par3='')
{
    $msg = '';
    if (isset($_POST['period_'. $name]) && $_POST['period_' . $name] > 0) {
        $msg = set_and_test_pref_array('period_' .$name, 0, $pkeys);
        if ($msg == '') {
            $msg = set_and_test_pref_numeric('time1_' . $name, 0, 0, 23);
        }
        if ($msg == '') {
            $msg = set_and_test_pref_numeric('time2_' . $name, 0, 0, 59);
        }
        if ($msg == '') {
            process_schedule($uc, $_POST['period_' . $name], $_POST['time1_'. $name ], $_POST['time2_'. $name ], $command, $par1, $par2);
        }

    } elseif (isset($_POST['period_'. $name])) {
        set_pref($db, 'period_'. $name, '', 0);
        set_pref($db, 'time1_'. $name, '', 0);
        set_pref($db, 'time2_'. $name, '', 0);
        $uc->unschedule(get_command($command), $par3);
    }

    return $msg;

}

/* Save changes: */
if ($cmd == 'submit_button') {
    challenge::verify_challenge($_POST['challenge']);
    $db->escape($_POST);
    $modules = array(urd_modules::URD_CLASS_GENERIC => TRUE);
    foreach ($_POST['module'] as $mod => $val) {
        $modules[$mod] = $val;
    }

    $log_level_msg = set_and_test_pref_array('log_level', 0, array_keys($log_levels));
    $scheduler_msg = set_and_test_pref_array('scheduler', 0, array_keys($on_off));
    if ($URDDONLINE) {
        try {
            list($pkeys, $ptexts) = $periods->get_periods();
            
            //en/disable the commands in URDD (also sets the db values)
            foreach ($modules as $mod => $val) {
                $msg = $uc->set('module', $mod, $val ? 'on' : 'off');
                if ($msg == TRUE) {
                    $modules_msg[$mod] = '';
                } else {
                    $module_msg[$mod] = make_error_msg($msg, $LN['error_error'] . ':');
                }
            }
            $getspots_blacklist_msg = update_periodic($db, 'getspots_blacklist', urdd_protocol::COMMAND_GETBLACKLIST, $uc, $pkeys);
            $getspots_whitelist_msg = update_periodic($db, 'getspots_whitelist', urdd_protocol::COMMAND_GETWHITELIST, $uc, $pkeys);
            $getspots_msg = update_periodic($db, 'getspots', urdd_protocol::COMMAND_GETSPOTS, $uc, $pkeys);
            $update_msg = update_periodic($db, 'update', urdd_protocol::COMMAND_CHECK_VERSION, $uc, $pkeys);
            $sendinfo_msg = update_periodic($db, 'sendinfo', urdd_protocol::COMMAND_SENDSETINFO, $uc, $pkeys);
            $getinfo_msg = update_periodic($db, 'getinfo', urdd_protocol::COMMAND_GETSETINFO, $uc, $pkeys);
            $nglist_msg = update_periodic($db, 'ng', urdd_protocol::COMMAND_GROUPS, $uc, $pkeys);
            $cleandb_msg = update_periodic($db, 'cdb', urdd_protocol::COMMAND_CLEANDB, $uc, $pkeys);
            $optimise_msg = update_periodic($db, 'opt', urdd_protocol::COMMAND_OPTIMISE, $uc, $pkeys);
            $cleanusers_msg = update_periodic($db, 'cu', urdd_protocol::COMMAND_CLEANDB, $uc, $pkeys, 'users', 'users', 'users');
            
            if (isset($_POST['period_cd']) && $_POST['period_cd'] > 0) {
                $cleandir_msg = set_and_test_pref_array('period_cd', 0, $pkeys);
                if ($cleandir_msg == '') {
                    $cleandir_msg = set_and_test_pref_numeric('time1_cd', 0, 0, 23);
                }
                if ($cleandir_msg == '') {
                    $cleandir_msg = set_and_test_pref_numeric('time2_cd', 0, 0, 59);
                }
                if ($cleandir_msg == '') {
                    $cleandir_msg = set_and_test_pref_array('dir_cd', 0, array_keys($cleandir_dirs));
                }
                if ($cleandir_msg == '') {
                    process_schedule($uc, $_POST['period_cd'], $_POST['time1_cd'], $_POST['time2_cd'], urdd_protocol::COMMAND_CLEANDIR, '__all', $_POST['dir_cd']);
                }
            } elseif (isset($_POST['period_cd'])) {
                set_pref($db, 'period_cd', '', 0);
                set_pref($db, 'time1_cd', '', 0);
                set_pref($db, 'time2_cd', '', 0);
                $dir = $rprefs['dir_cd'];
                $uc->unschedule(get_command(urdd_protocol::COMMAND_CLEANDIR), "$dir");
            }
            if (isset($_POST['period_opt']) && $_POST['period_opt'] > 0) {
                $optimise_msg = set_and_test_pref_array('period_opt', 0, $pkeys);
                if ($optimise_msg === '') {
                    $optimise_msg = set_and_test_pref_numeric('time1_opt', 0, 0, 23);
                }
                if ($optimise_msg === '') {
                    $optimise_msg = set_and_test_pref_numeric('time2_opt', 0, 0, 59);
                }
                if ($optimise_msg === '') {
                    process_schedule($uc, $_POST['period_opt'], $_POST['time1_opt'], $_POST['time2_opt'], urdd_protocol::COMMAND_OPTIMISE, '', '');
                }
            } elseif (isset($_POST['period_opt'])) {
                set_pref($db, 'period_opt', '', 0);
                set_pref($db, 'time1_opt', '', 0);
                set_pref($db, 'time2_opt', '', 0);
                $uc->unschedule(get_command(urdd_protocol::COMMAND_OPTIMISE), '');
                // unschedule update
            }
            $clean_dir_age_msg = set_and_test_pref_numeric('clean_dir_age', 0, 0);
            $clean_db_age_msg = set_and_test_pref_numeric('clean_db_age', 0, 0);
            if ($log_level_msg == '' && $URDDONLINE) {
                $uc->set('log_level', $log_str[$_POST['log_level']]);
            }
            
            if ($log_level_msg == '' && $URDDONLINE) {
                $uc->set('scheduler', $_POST['scheduler']);
            }
        }
        catch(exception$e) {
            $__message[] = $LN['error_schedulesnotset'] ;
            $__message[] = $e;
        }
    } else {
        // if URDD is offline we simply set the db config
        urd_modules::update_urd_modules($db, $modules, $module_msg);
        foreach ($module_msg as $k => $m) {
            if ($m != '') {
                $module_msg[$k] = make_error_msg($m, $LN['error_error'] .  ':');
            }
        }
    }
	$poster_blacklist_msg = set_and_test_pref_text_area('poster_blacklist', 0, TRUE);
    $users_clean_age_msg = set_and_test_pref_numeric('users_clean_age', 0, 0);
    $socket_timeout_msg = set_and_test_pref_numeric('socket_timeout', 0, 0);
    $urdd_connection_timeout_msg = set_and_test_pref_numeric('urdd_connection_timeout', 0, 0);
    $index_page_msg = set_and_test_pref_array('index_page_root', 0, array_keys($index_page_array));
    $auto_login_msg = set_and_test_pref_array('auto_login', 0, array_keys($users));
    $admin_email_msg = set_and_test_pref_email('admin_email', 0);
    $group_msg = set_and_test_pref_group('group', 0, TRUE);
    $allow_robots_msg = set_and_test_pref_bool('allow_robots', 0, $allow_robots);
    $download_spots_comments_msg = set_and_test_pref_bool('download_spots_comments', 0, $download_spots_comments);
    $download_spots_reports_msg = set_and_test_pref_bool('download_spots_reports', 0, $download_spots_reports);
    $download_spots_images_msg = set_and_test_pref_bool('download_spots_images', 0, $download_spots_imags);
    $shaping_msg = set_and_test_pref_bool('shaping', 0, $shaping);
    $parse_nfo_msg = set_and_test_pref_bool('parse_nfo', 0, $parse_nfo);
    $sendmail_msg = set_and_test_pref_bool('sendmail', 0, $sendmail);
    $follow_link_msg = set_and_test_pref_bool('follow_link', 0, $follow_link);
    $clicjack_msg = set_and_test_pref_bool('clickjack', 0, $clickjack);
    $check_nntp_connections_msg = set_and_test_pref_bool('check_nntp_connections', 0, $check_nntp_connections);
    $auto_download_msg = set_and_test_pref_bool('auto_download', 0, $auto_download);
    $compress_nzb_msg = set_and_test_pref_bool('compress_nzb', 0, $compress_nzb);
    $webdownload_msg = set_and_test_pref_bool('webdownload', 0, $webdownload);
    $webeditfile_msg = set_and_test_pref_bool('webeditfile', 0, $webeditfile);
    $global_scripts_msg = set_and_test_pref_bool('allow_global_scripts', 0, $global_scripts);
    $user_scripts_msg = set_and_test_pref_bool('allow_user_scripts', 0, $user_scripts);
    $auto_expire_msg = set_and_test_pref_bool('auto_expire', 0, $foo);
    $auto_getnfo_msg = set_and_test_pref_bool('auto_getnfo', 0, $foo);
    $urdd_restart_msg = set_and_test_pref_bool('urdd_restart', 0, $foo);
    $urdd_daemonise_msg = set_and_test_pref_bool('urdd_daemonise', 0, $foo);
    $auto_reg_msg = set_and_test_pref_bool('auto_reg', 0, $foo);
    $register_msg = set_and_test_pref_bool('register', 0, $foo);
    $keep_int_msg = set_and_test_pref_bool('keep_interesting', 0, $foo);
    $default_template_msg = set_and_test_pref_array('default_template', 0, array_keys($templates));
    $default_stylesheet_msg = set_and_test_pref_array('default_stylesheet', 0, array_keys($stylesheets));

    $mail_account_activated_msg = set_and_test_pref_array('mail_account_activated', 0, array_keys($mail_templates));
    $mail_account_disabled_msg = set_and_test_pref_array('mail_account_disabled', 0, array_keys($mail_templates));
    $mail_activate_account_msg = set_and_test_pref_array('mail_activate_account', 0, array_keys($mail_templates));
    $mail_download_status_msg = set_and_test_pref_array('mail_download_status', 0, array_keys($mail_templates));
    $mail_new_interesting_sets_msg = set_and_test_pref_array('mail_new_interesting_sets', 0, array_keys($mail_templates));
    $mail_new_preferences_msg = set_and_test_pref_array('mail_new_preferences', 0, array_keys($mail_templates));
    $mail_new_user_msg = set_and_test_pref_array('mail_new_user', 0, array_keys($mail_templates));
    $mail_password_reset_msg = set_and_test_pref_array('mail_password_reset', 0, array_keys($mail_templates));

    $default_language_msg = set_and_test_pref_array('default_language', 0, array_keys($languages));
    $permissions_msg = set_and_test_pref_array('permissions', 0, array_keys($permissions));
    $pidpath_msg = set_and_test_pref_path('pidpath', 0, $_POST['pidpath']);
        
    $dlpath_msg = set_and_test_pref_dlpath('dlpath', 0, $_POST['dlpath']);
    if ($shaping) {
        $maxdl_msg = set_and_test_pref_numeric('maxdl', 0, 0, NULL, 1024, 'k');
        $maxul_msg = set_and_test_pref_numeric('maxul', 0, 0, NULL, 1024, 'k');
    }
    $maxexpire_msg = set_and_test_pref_numeric('maxexpire', 0, 0);
    $max_login_count_msg = set_and_test_pref_numeric('max_login_count', 0, 0);
    $maxheaders_msg = set_and_test_pref_numeric('maxheaders', 0, 1);
    $queue_size_msg = set_and_test_pref_numeric('queue_size', 0, 1);
    $maxfilesize_msg = set_and_test_pref_numeric('maxfilesize', 0, 0, NULL, 1024, 'k');
    $maxpreviewsize_msg = set_and_test_pref_numeric('maxpreviewsize', 0, 0, NULL, 1024, 'k');
    $nice_value_msg = set_and_test_pref_numeric('nice_value', 0, 0, 19);
    $total_max_articles_msg = set_and_test_pref_numeric('total_max_articles', 0, 0);
    $max_dl_name_msg = set_and_test_pref_numeric('max_dl_name', 0, 16);
    $hidden_files_list_msg = set_and_test_pref_text_area('global_hidden_files_list', 0, TRUE);
    $hiddenfiles_msg = set_and_test_pref_bool('global_hiddenfiles', 0, $foo);
    $urdd_path_msg = set_and_test_pref_prog('urdd_path', 0);
    $trickle_path_msg = set_and_test_pref_prog('trickle_path', 0, TRUE);
    $yydecode_path_msg = set_and_test_pref_prog('yydecode_path', 0);
    $yyencode_path_msg = set_and_test_pref_prog('yyencode_path', 0, TRUE);
    $cksfv_path_msg = set_and_test_pref_prog('cksfv_path', 0, TRUE);
    $unrar_path_msg = set_and_test_pref_prog('unrar_path', 0, TRUE);
    $rar_path_msg = set_and_test_pref_prog('rar_path', 0, TRUE);
    $unpar_path_msg = set_and_test_pref_prog('unpar_path', 0, TRUE);
    $unace_path_msg = set_and_test_pref_prog('unace_path', 0, TRUE);
    $unzip_path_msg = set_and_test_pref_prog('unzip_path', 0, TRUE);
    $un7zr_path_msg = set_and_test_pref_prog('un7zr_path', 0, TRUE);
    $unarj_path_msg = set_and_test_pref_prog('unarj_path', 0, TRUE);
    $subdownloader_path_msg = set_and_test_pref_prog('subdownloader_path', 0, TRUE);
    $gzip_path_msg = set_and_test_pref_prog('gzip_path', 0, TRUE);
    $file_path_msg = set_and_test_pref_prog('file_path', 0, FALSE);
    $tar_path_msg = set_and_test_pref_prog('tar_path', 0, TRUE);
    $urdd_host_msg = set_and_test_pref_text('urdd_host', 0, '[a-zA-Z0-9.\-_:\[\]]');
    $replacement_str_msg = set_and_test_pref_text('replacement_str', 0, '[a-zA-Z0-9.\-_:\[\] ()!@#$%^&{}+;]', TRUE, TRUE);
    $group_filter_msg = set_and_test_pref_text('group_filter', 0, '[a-zA-Z0-9.*, ?]', TRUE, TRUE);
    $extset_group_msg = set_and_test_pref_text('extset_group', 0, '[a-zA-Z0-9.]', TRUE, FALSE);
    $spots_group_msg = set_and_test_pref_text('spots_group', 0, '[a-zA-Z0-9.]', TRUE, FALSE);
    $spots_reports_group_msg = set_and_test_pref_text('spots_reports_group', 0, '[a-zA-Z0-9.]', TRUE, FALSE);
    $spots_comments_group_msg = set_and_test_pref_text('spots_comments_group', 0, '[a-zA-Z0-9.]', TRUE, FALSE);
    $ftd_group_msg = set_and_test_pref_text('ftd_group', 0, '[a-zA-Z0-9.]', TRUE, FALSE);
    $spots_blacklist_msg = set_and_test_pref_text('spots_blacklist', 0, '[a-zA-Z0-9.:\/+;&%#+_\-]', TRUE, FALSE);
    $spots_whitelist_msg = set_and_test_pref_text('spots_whitelist', 0, '[a-zA-Z0-9.:\/+;&%#+_\-]', TRUE, FALSE);
    $urdd_uid_msg = set_and_test_pref_text('urdd_uid', 0, '[a-zA-Z0-9-.]', TRUE, FALSE);
    $urdd_gid_msg = set_and_test_pref_text('urdd_gid', 0, '[a-zA-Z0-9-.]', TRUE, FALSE);
    $url_msg = set_and_test_pref_url('url', 0);
    $urdd_port_msg = set_and_test_pref_numeric('urdd_port', 0, 1, 65535);
    $urdd_maxthreads_msg = set_and_test_pref_numeric('urdd_maxthreads', 0, 1);
    $nntp_maxthreads_msg = set_and_test_pref_numeric('nntp_maxthreads', 0, 1);
    $nntp_maxdlthreads_msg = set_and_test_pref_numeric('nntp_maxdlthreads', 0, 0);
    $db_intensive_maxthreads_msg = set_and_test_pref_numeric('db_intensive_maxthreads', 0, 0);
    $default_expire_time_msg = set_and_test_pref_numeric('default_expire_time', 0, 1);
    $spots_expire_time_msg = set_and_test_pref_numeric('spots_expire_time', 0, 0);
    if ($spots_expire_time_msg == '') {
        set_spots_expire($db, $_POST['spots_expire_time']);
    }   
    $expire_incomplete_msg = set_and_test_pref_numeric('expire_incomplete', 0, 0);
    $expire_percentage_msg = set_and_test_pref_numeric('expire_percentage', 0, 0, 100);
    $maxbuttons_msg = set_and_test_pref_numeric('maxbuttons', 0, 1);
    $urdd_pars_msg = set_and_test_pref_text('urdd_pars', 0, NULL, TRUE);
    $unpar_pars_msg = set_and_test_pref_text('unpar_pars', 0, NULL, TRUE);
    $unrar_pars_msg = set_and_test_pref_text('unrar_pars', 0, NULL, TRUE);
    $rar_pars_msg = set_and_test_pref_text('rar_pars', 0, NULL, TRUE);
    $unace_pars_msg = set_and_test_pref_text('unace_pars', 0, NULL, TRUE);
    $un7zr_pars_msg = set_and_test_pref_text('un7zr_pars', 0, NULL, TRUE);
    $unzip_pars_msg = set_and_test_pref_text('unzip_pars', 0, NULL, TRUE);
    $unarj_pars_msg = set_and_test_pref_text('unarj_pars', 0, NULL, TRUE);
    $subdownloader_pars_msg = set_and_test_pref_text('subdownloader_pars', 0, NULL, TRUE);
    $gzip_pars_msg = set_and_test_pref_text('gzip_pars', 0, NULL, TRUE);
    $yyencode_pars_msg = set_and_test_pref_text('yyencode_pars', 0, NULL, TRUE);
    $yydecode_pars_msg = set_and_test_pref_text('yydecode_pars', 0, NULL, TRUE);
    foreach ($SETTYPES as $t) {
        $settype_msg[$t] = set_and_test_pref_text("settype_$t", 0, NULL, TRUE);
    }
    $saved = 1;
} elseif ($cmd == 'reset') {
    challenge::verify_challenge($_POST['challenge']);
    /* Reset config */
    try {

        if ($URDDONLINE) {
            $prefArray = get_default_config();
            $uc->set('log_level', $prefArray['log_level']);

            $uc->unschedule(get_command(urdd_protocol::COMMAND_CLEANDIR), '__all');
            $uc->unschedule(get_command(urdd_protocol::COMMAND_CLEANDB), 'users');
            $uc->unschedule(get_command(urdd_protocol::COMMAND_CLEANDB), '');
            $uc->unschedule(get_command(urdd_protocol::COMMAND_CHECK_VERSION), '');
            $uc->unschedule(get_command(urdd_protocol::COMMAND_GROUPS), '');
            $uc->unschedule(get_command(urdd_protocol::COMMAND_OPTIMISE), '');
            $uc->unschedule(get_command(urdd_protocol::COMMAND_GETSETINFO), '');
            $uc->unschedule(get_command(urdd_protocol::COMMAND_SENDSETINFO), '');
        }
    }
    catch(exception $e) {
        $__message[] = $LN['error_schedulesnotset'];
        $__message[] = $e;
    }
    reset_config($db);
}

/* Get all current settings and do sanity check: */
$prefArray_root = get_default_config();
$prefArray_root = array_merge($prefArray_root, load_config($db, TRUE));

// need to reload this one cause the settings may have changes to modules
$index_page_array = get_index_page_array($isadmin, urd_modules::get_urd_module_config($prefArray_root['modules']));

foreach ($SETTYPES as $t) {
    if (!isset($settype_msg[$t])) {
        $settype_msg[$t] = verify_text($prefArray_root["settype_$t"]);
    }
}

if (!isset($poster_blacklist_msg)) {
	$poster_blacklist_msg = verify_text_area($prefArray_root['poster_blacklist']);
}
if (!isset($index_page_msg)) {
    $index_page_msg = verify_array($prefArray_root['index_page_root'], array_keys($index_page_array));
}
if (!isset($group_msg)) {
    $group_msg = verify_group($prefArray_root['group'], TRUE);
}
if (!isset($permissions_msg)) {
    $permissions_msg = verify_array($prefArray_root['permissions'], array_keys($permissions));
}
if (!isset($log_level_msg)) {
    $log_level_msg = verify_array($prefArray_root['log_level'], array_keys($log_levels));
}
if (!isset($scheduler_msg)) {
    $scheduler_msg = verify_array($prefArray_root['scheduler'], array_keys($on_off));
}
if (!isset($hidden_files_list_msg)) {
    $hidden_files_list_msg = verify_text_area($prefArray_root['global_hidden_files_list']);
}
if (!isset($url_msg)) {
    $url_msg = verify_url($prefArray_root['url']);
}
if (!isset($admin_email_msg)) {
    $admin_email_msg = verify_email_address($prefArray_root['admin_email']);
}
if (!isset($unrar_path_msg)) {
    $unrar_path_msg = verify_prog($prefArray_root['unrar_path'], TRUE);
}
if (!isset($rar_path_msg)) {
    $rar_path_msg = verify_prog($prefArray_root['rar_path'], TRUE);
}
if (!isset($unarj_path_msg)) {
    $unarj_path_msg = verify_prog($prefArray_root['unarj_path'], TRUE);
}
if (!isset($subdownloader_path_msg)) {
    $subdownloader_path_msg = verify_prog($prefArray_root['subdownloader_path'], TRUE);
}
if (!isset($file_path_msg)) {
    $file_path_msg = verify_prog($prefArray_root['file_path'], TRUE);
}
if (!isset($tar_path_msg)) {
    $tar_path_msg = verify_prog($prefArray_root['tar_path'], TRUE);
}
if (!isset($gzip_path_msg)) {
    $gzip_path_msg = verify_prog($prefArray_root['gzip_path'], TRUE);
}
if (!isset($unzip_path_msg)) {
    $unzip_path_msg = verify_prog($prefArray_root['unzip_path'], TRUE);
}
if (!isset($un7zr_path_msg)) {
    $un7zr_path_msg = verify_prog($prefArray_root['un7zr_path'], TRUE);
}
if (!isset($unace_path_msg)) {
    $unace_path_msg = verify_prog($prefArray_root['unace_path'], TRUE);
}
if (!isset($unpar_path_msg)) {
    $unpar_path_msg = verify_prog($prefArray_root['unpar_path'], TRUE);
}
if (!isset($yydecode_path_msg)) {
    $yydecode_path_msg = verify_prog($prefArray_root['yydecode_path']);
}
if (!isset($yyencode_path_msg)) {
    $yyencode_path_msg = verify_prog($prefArray_root['yyencode_path'], TRUE);
}
if (!isset($urdd_path_msg)) {
    $urdd_path_msg = verify_prog($prefArray_root['urdd_path']);
}
if (!isset($cksfv_path_msg)) {
    $cksfv_path_msg = verify_prog($prefArray_root['cksfv_path'], TRUE);
}
if (!isset($trickle_path_msg)) {
    $trickle_path_msg = verify_prog($prefArray_root['trickle_path'], TRUE);
}
if (!isset($urdd_maxthreads_msg)) {
    $urdd_maxthreads_msg = verify_numeric($prefArray_root['urdd_maxthreads'], 1);
}
if (!isset($nntp_maxdlthreads_msg)) {
    $nntp_maxdlthreads_msg = verify_numeric($prefArray_root['nntp_maxdlthreads'], 0);
}
if (!isset($clean_dir_age_msg)) {
    $clean_dir_age_msg = verify_numeric($prefArray_root['clean_dir_age'], 0);
}
if (!isset($users_clean_age_msg)) {
    $users_clean_age_msg = verify_numeric($prefArray_root['users_clean_age'], 0);
}
if (!isset($max_dl_name_msg)) {
    $max_dl_name_msg = verify_numeric($prefArray_root['max_dl_name'], 16);
}
if (!isset($clean_db_age_msg)) {
    $clean_db_age_msg = verify_numeric($prefArray_root['clean_db_age'], 0);
}
if (!isset($nntp_maxthreads_msg)) {
    $nntp_maxthreads_msg = verify_numeric($prefArray_root['nntp_maxthreads'], 1);
}
if (!isset($db_intensive_maxthreads_msg)) {
    $db_intensive_maxthreads_msg = verify_numeric($prefArray_root['db_intensive_maxthreads'], 1);
}
if (!isset($maxfilesize_msg)) {
    $maxfilesize_msg = verify_numeric($prefArray_root['maxfilesize'], 0);
}
if (!isset($maxpreviewsize_msg)) {
    $maxpreviewsize_msg = verify_numeric($prefArray_root['maxpreviewsize'], 0);
}
if (!isset($maxexpire_msg)) {
    $maxexpire_msg = verify_numeric($prefArray_root['maxexpire'], 0);
}
if (!isset($max_login_count_msg)) {
    $max_login_count_msg = verify_numeric($prefArray_root['max_login_count'], 0);
}
if (!isset($maxheaders_msg)) {
    $maxheaders_msg = verify_numeric($prefArray_root['maxheaders'], 0);
}
if (!isset($queue_size_msg)) {
    $queue_size_msg = verify_numeric($prefArray_root['queue_size'], 0);
}
if (!isset($urdd_connection_timeout_msg)) {
    $urdd_connection_timeout_msg = verify_numeric($prefArray_root['urdd_connection_timeout'], 0);
}
if (!isset($socket_timeout_msg)) {
    $socket_timeout_msg = verify_numeric($prefArray_root['socket_timeout'], 0);
}
if (!isset($total_max_articles_msg)) {
    $total_max_articles_msg = verify_numeric($prefArray_root['total_max_articles'], 0);
}
if (!isset($nice_value_msg)) {
    $nice_value_msg = verify_numeric($prefArray_root['nice_value'], 0, 19);
}
if (!isset($urdd_port_msg)) {
    $urdd_port_msg = verify_numeric($prefArray_root['urdd_port'], 1, 65535);
}
if (!isset($urdd_host_msg)) {
    $urdd_host_msg = verify_text($prefArray_root['urdd_host'], '[a-zA-Z0-9.\-_:\[\]]');
}
if (!isset($urdd_uid_msg)) {
    $urdd_uid_msg = verify_text($prefArray_root['urdd_uid'], '[a-zA-Z0-9.-]');
}
if (!isset($urdd_gid_msg)) {
    $urdd_gid_msg = verify_text($prefArray_root['urdd_gid'], '[a-zA-Z0-9.-]');
}
if (!isset($replacement_str_msg)) {
    $replacement_str_msg = verify_text_opt($prefArray_root['replacement_str'], 0, '[a-zA-Z0-9.\-_:\[\] ()!@#$%^&{}+;]');
}
if (!isset($group_filter_msg)) {
    $group_filter_msg = verify_text_opt($prefArray_root['group_filter'], 0, '[a-zA-Z0-9.*?, ]');
}
if (!isset($spots_reports_group_msg)) {
    $spots_reports_group_msg = verify_text_opt($prefArray_root['spots_reports_group'], 0, '[a-zA-Z0-9.]');
}
if (!isset($spots_group_msg)) {
    $spots_group_msg = verify_text_opt($prefArray_root['spots_group'], 0, '[a-zA-Z0-9.]');
}
if (!isset($spots_comments_group_msg)) {
    $spots_comments_group_msg = verify_text_opt($prefArray_root['spots_comments_group'], 0, '[a-zA-Z0-9.]');
}
if (!isset($ftd_group_msg)) {
    $ftd_group_msg = verify_text_opt($prefArray_root['ftd_group'], 0, '[a-zA-Z0-9.]');
}
if (!isset($spots_blacklist_msg)) {
    $spots_blacklist_msg = verify_text_opt($prefArray_root['spots_blacklist'], 0, '[a-zA-Z0-9.:\/&%#;+_\-]');
}
if (!isset($spots_whitelist_msg)) {
    $spots_whitelist_msg = verify_text_opt($prefArray_root['spots_whitelist'], 0, '[a-zA-Z0-9.:\/&%#;+_\-]');
}
if (!isset($extset_group_msg)) {
    $extset_group_msg = verify_text_opt($prefArray_root['extset_group'], 0, '[a-zA-Z0-9.]');
}
if (!isset($dlpath_msg)) {
    $dlpath_msg = verify_dlpath($db, $prefArray_root['dlpath']);
}
if (!isset($pidpath_msg)) {
    $pidpath_msg = verify_path($db, $prefArray_root['pidpath']);
}
if (!isset($maxdl_msg)) {
    $maxdl_msg = verify_numeric($prefArray_root['maxdl'], 0);
}
if (!isset($maxul_msg)) {
    $maxul_msg = verify_numeric($prefArray_root['maxul'], 0);
}
if (!isset($default_expire_time_msg)) {
    $default_expire_time_msg = verify_numeric($prefArray_root['default_expire_time'], 1);
}
if (!isset($spots_expire_time_msg)) {
    $spots_expire_time_msg = verify_numeric($prefArray_root['spots_expire_time'], 0);
}
if (!isset($expire_incomplete_msg)) {
    $expire_incomplete_msg = verify_numeric($prefArray_root['expire_incomplete'], 0);
}
if (!isset($expire_percentage_msg)) {
    $expire_percentage_msg = verify_numeric($prefArray_root['expire_percentage'], 0, 100);
}
if (!isset($default_language_msg)) {
    $default_language_msg = verify_array($prefArray_root['default_language'], array_keys($languages));
}
if (!isset($auto_login_msg)) {
    $auto_login_msg = verify_array($prefArray_root['auto_login'], array_keys($users));
}
if (!isset($default_template_msg)) {
    $default_template_msg = verify_array($prefArray_root['default_template'], array_keys($templates));
}
if (!isset($mail_account_activated_msg)) {
    $mail_account_activated_msg= verify_array($prefArray_root['mail_account_activated'], array_keys($mail_templates));
}
if (!isset($mail_account_disabled_msg)) {
    $mail_account_disabled_msg= verify_array($prefArray_root['mail_account_disabled'], array_keys($mail_templates));
}
if (!isset($mail_activate_account_msg)) {
    $mail_activate_account_msg= verify_array($prefArray_root['mail_activate_account'], array_keys($mail_templates));
}
if (!isset($mail_download_status_msg)) {
    $mail_download_status_msg= verify_array($prefArray_root['mail_download_status'], array_keys($mail_templates));
}
if (!isset($mail_new_interesting_sets_msg)) {
    $mail_new_interesting_sets_msg= verify_array($prefArray_root['mail_new_interesting_sets'], array_keys($mail_templates));
}
if (!isset($mail_new_preferences_msg)) {
    $mail_new_preferences_msg= verify_array($prefArray_root['mail_new_preferences'], array_keys($mail_templates));
}
if (!isset($mail_new_user_msg)) {
    $mail_new_user_msg= verify_array($prefArray_root['mail_new_user'], array_keys($mail_templates));
}
if (!isset($mail_password_reset_msg)) {
    $mail_password_reset_msg= verify_array($prefArray_root['mail_password_reset'], array_keys($mail_templates));
}
if (!isset($default_stylesheet_msg)) {
    $default_stylesheet_msg = verify_array($prefArray_root['default_stylesheet'], array_keys($stylesheets));
}
if (!isset($maxbuttons_msg)) {
    $maxbuttons_msg = verify_numeric($prefArray_root['maxbuttons'], 0);
}
if (!isset($update_msg)) {
    $update_msg = verify_array($prefArray_root['period_update'], $periods->get_period_keys());
}
if ($prefArray_root['period_getspots_blacklist'] > 0) {
    if (!isset($getspots_msg)) {
        $getspots_blacklist_msg = verify_numeric($prefArray_root['time1_getspots_blacklist'], 0, 23);
        $getspots_blacklist_msg .= verify_numeric($prefArray_root['time2_getspots_blacklist'], 0, 59);
    }
} else {
    $getspots_blacklist_msg = '';
}
if ($prefArray_root['period_getspots_whitelist'] > 0) {
    if (!isset($getspots_msg)) {
        $getspots_whitelist_msg = verify_numeric($prefArray_root['time1_getspots_whitelist'], 0, 23);
        $getspots_whitelist_msg .= verify_numeric($prefArray_root['time2_getspots_whitelist'], 0, 59);
    }
} else {
    $getspots_whitelist_msg = '';
}

if ($prefArray_root['period_getspots'] > 0) {
    if (!isset($getspots_msg)) {
        $getspots_msg = verify_numeric($prefArray_root['time1_getspots'], 0, 23);
        $getspots_msg .= verify_numeric($prefArray_root['time2_getspots'], 0, 59);
    }
} else {
    $getspots_msg = '';
}
if ($prefArray_root['period_update'] > 0) {
    if (!isset($update_msg)) {
        $update_msg = verify_numeric($prefArray_root['time1_update'], 0, 23);
        $update_msg .= verify_numeric($prefArray_root['time2_update'], 0, 59);
    }
} else {
    $update_msg = '';
}
if ($prefArray_root['period_sendinfo'] > 0) {
    if (!isset($sendinfo_msg)) {
        $sendinfo_msg = verify_numeric($prefArray_root['time1_sendinfo'], 0, 23);
        $sendinfo_msg .= verify_numeric($prefArray_root['time2_sendinfo'], 0, 59);
    }
} else {
    $sendinfo_msg = '';
}
if ($prefArray_root['period_getinfo'] > 0) {
    if (!isset($getinfo_msg)) {
        $getinfo_msg = verify_numeric($prefArray_root['time1_getinfo'], 0, 23);
        $getinfo_msg .= verify_numeric($prefArray_root['time2_getinfo'], 0, 59);
    }
} else {
    $getinfo_msg = '';
}

if (!isset($nglist_msg)) {
    $nglist_msg = verify_array($prefArray_root['period_ng'], $periods->get_period_keys());
}
if ($prefArray_root['period_ng'] > 0) {
    if (!isset($nglist_msg)) {
        $nglist_msg .= verify_numeric($prefArray_root['time1_ng'], 0, 23);
        $nglist_msg .= verify_numeric($prefArray_root['time2_ng'], 0, 59);
    }
} else {
    $nglist_msg = '';
}
if (!isset($cleandb_msg)) {
    $cleandb_msg = verify_array($prefArray_root['period_cdb'], $periods->get_period_keys());
}
if ($prefArray_root['period_cdb'] > 0) {
    if (!isset($cleandb_msg)) {
        $cleandb_msg = verify_numeric($prefArray_root['time1_cdb'], 0, 23);
        $cleandb_msg .= verify_numeric($prefArray_root['time2_cdb'], 0, 59);
    }
} else {
    $cleandb_msg = '';
}
if (!isset($cleanusers_msg)) {
    $cleanusers_msg = verify_array($prefArray_root['period_cu'], $periods->get_period_keys());
}
if ($prefArray_root['period_cu'] > 0) {
    if (!isset($cleanusers_msg)) {
        $cleanusers_msg = verify_numeric($prefArray_root['time1_cu'], 0, 23);
        $cleanusers_msg .= verify_numeric($prefArray_root['time2_cu'], 0, 59);
    }
} else {
    $cleanusers_msg = '';
}

if (!isset($cleandir_msg)) {
    $cleandir_msg = verify_array($prefArray_root['period_cd'], $periods->get_period_keys());
}
if ($prefArray_root['period_cd'] > 0) {
    if (!isset($cleandir_msg)) {
        $cleandir_msg = verify_numeric($prefArray_root['time1_cd'], 0, 23);
        $cleandir_msg .= verify_numeric($prefArray_root['time2_cd'], 0, 59);
        $cleandir_msg .= verify_array($prefArray_root['dir_cd'], 0, array_keys($cleandir_dirs));
    }
} else {
    $cleandir_msg = '';
}
if (!isset($optimise_msg)) {
    $optimise_msg = verify_array($prefArray_root['period_opt'], $periods->get_period_keys());
}
if ($prefArray_root['period_opt'] > 0) {
    if (!isset($optimise_msg)) {
        $optimise_msg = verify_numeric($prefArray_root['time1_opt'], 0, 23);
        $optimise_msg .= verify_numeric($prefArray_root['time2_opt'], 0, 59);
    }
} else {
    $optimise_msg = '';
}

if (!isset($urdd_pars_msg)) {
    $urdd_pars_msg = verify_text_opt('urdd_pars', TRUE, NULL);
}
if (!isset($unpar_pars_msg)) {
    $unpar_pars_msg = verify_text_opt('unpar_pars', TRUE, NULL);
}
if (!isset($unrar_pars_msg)) {
    $unrar_pars_msg = verify_text_opt('unrar_pars', TRUE, NULL);
}
if (!isset($rar_pars_msg)) {
    $rar_pars_msg = verify_text_opt('rar_pars', TRUE, NULL);
}
if (!isset($unace_pars_msg)) {
    $unace_pars_msg = verify_text_opt('unace_pars', TRUE, NULL);
}
if (!isset($un7zr_pars_msg)) {
    $un7zr_pars_msg = verify_text_opt('un7zr_pars', TRUE, NULL);
}
if (!isset($unzip_pars_msg)) {
    $unzip_pars_msg = verify_text_opt('unzip_pars', TRUE, NULL);
}
if (!isset($gzip_pars_msg)) {
    $gzip_pars_msg = verify_text_opt('gzip_pars', TRUE, NULL);
}
if (!isset($unarj_pars_msg)) {
    $unarj_pars_msg = verify_text_opt('unarj_pars', TRUE, NULL);
}
if (!isset($subdownloader_pars_msg)) {
    $subdownloader_pars_msg = verify_text_opt('subdownloader_pars', TRUE, NULL);
}
if (!isset($yydecode_pars_msg)) {
    $yydecode_pars_msg = verify_text_opt('yydecode_pars', TRUE, NULL);
}
if (!isset($yyencode_pars_msg)) {
    $yyencode_pars_msg = verify_text_opt('yyencode_pars', TRUE, NULL);
}


$poster_blacklist = ($prefArray_root['poster_blacklist']);
$poster_blacklist = clean_textarea_data($poster_blacklist);
$poster_blacklist = clean_list($poster_blacklist);

$hidden_files_list = $prefArray_root['global_hidden_files_list'];
$hidden_files_list = str_replace('\n', "\n", $hidden_files_list);
$hidden_files_list = str_replace('\r', '', $hidden_files_list);
$hidden_files_list = clean_list($hidden_files_list);

$module_config = urd_modules::get_urd_module_config($prefArray_root['modules']);

$urdd_cfg = array(
    new pref_numeric_noformat(user_levels::CONFIG_LEVEL_BASIC, $LN['config_max_threads'], 'urdd_maxthreads', $LN['config_max_threads_msg'], $urdd_maxthreads_msg, $prefArray_root['urdd_maxthreads'], NUMBER_BOX_SIZE),
    new pref_numeric_noformat(user_levels::CONFIG_LEVEL_BASIC, $LN['config_max_nntp'], 'nntp_maxthreads', $LN['config_max_nntp_msg'], $nntp_maxthreads_msg, $prefArray_root['nntp_maxthreads'], NUMBER_BOX_SIZE), 
    new pref_numeric_noformat(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_max_dlnntp'], 'nntp_maxdlthreads', $LN['config_max_dlnntp_msg'], $nntp_maxdlthreads_msg, $prefArray_root['nntp_maxdlthreads'], NUMBER_BOX_SIZE),
    new pref_numeric_noformat(user_levels::CONFIG_LEVEL_MASTER, $LN['config_max_db_intensive'], 'db_intensive_maxthreads', $LN['config_max_db_intensive_msg'], $db_intensive_maxthreads_msg, $prefArray_root['db_intensive_maxthreads'], NUMBER_BOX_SIZE), 
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_check_nntp_connections'], 'check_nntp_connections', $LN['config_check_nntp_connections_msg'], $check_nntp_connections_msg, $prefArray_root['check_nntp_connections']),
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_dlpath'], 'dlpath', $LN['config_dlpath_msg'], $dlpath_msg, $prefArray_root['dlpath'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_urddhostname'], 'urdd_host', $LN['config_urddhostname_msg'], $urdd_host_msg, $prefArray_root['urdd_host'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_urddport'], 'urdd_port', $LN['config_urddport_msg'], $urdd_port_msg, $prefArray_root['urdd_port'], NUMBER_BOX_SIZE), 
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_restart'], 'urdd_restart', $LN['config_restart_msg'], $urdd_restart_msg, $prefArray_root['urdd_restart']),
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_daemonise'], 'urdd_daemonise', $LN['config_daemonise_msg'], $urdd_daemonise_msg, $prefArray_root['urdd_daemonise']),
    new pref_select(user_levels::CONFIG_LEVEL_MASTER, $LN['config_scheduler'], 'scheduler', $LN['config_scheduler_msg'], $scheduler_msg, $on_off, $prefArray_root['scheduler']),
    new pref_numeric_noformat(user_levels::CONFIG_LEVEL_MASTER, $LN['config_max_dl_name'], 'max_dl_name', $LN['config_max_dl_name_msg'], $max_dl_name_msg, $prefArray_root['max_dl_name'], NUMBER_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_nice_value'], 'nice_value', $LN['config_nice_value_msg'], $nice_value_msg, $prefArray_root['nice_value'], NUMBER_BOX_SIZE),
    new pref_numeric_noformat(user_levels::CONFIG_LEVEL_MASTER, $LN['config_queue_size'], 'queue_size', $LN['config_queue_size_msg'], $queue_size_msg, $prefArray_root['queue_size'], NUMBER_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_pidpath'], 'pidpath', $LN['config_pidpath_msg'], $dlpath_msg, $prefArray_root['pidpath'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_urdd_uid'], 'urdd_uid', $LN['config_urdd_uid_msg'], $urdd_uid_msg, $prefArray_root['urdd_uid'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_urdd_gid'], 'urdd_gid', $LN['config_urdd_gid_msg'], $urdd_gid_msg, $prefArray_root['urdd_gid'], TEXT_BOX_SIZE)
);

$networking = array(
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_adminemail'], 'admin_email', $LN['config_adminemail_msg'], $admin_email_msg, $prefArray_root['admin_email'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_baseurl'], 'url', $LN['config_baseurl_msg'], $url_msg, $prefArray_root['url'], TEXT_BOX_SIZE),
    new pref_numeric(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_socket_timeout'], 'socket_timeout', $LN['config_socket_timeout_msg'], $socket_timeout_msg, $prefArray_root['socket_timeout'], NUMBER_BOX_SIZE), 
    new pref_numeric(user_levels::CONFIG_LEVEL_MASTER, $LN['config_urdd_connection_timeout'], 'urdd_connection_timeout', $LN['config_urdd_connection_timeout_msg'], $urdd_connection_timeout_msg, $prefArray_root['urdd_connection_timeout'], NUMBER_BOX_SIZE), 
    new pref_checkbox(user_levels::CONFIG_LEVEL_MASTER, $LN['config_shaping'], 'shaping', $LN['config_shaping_msg'], $shaping_msg, $prefArray_root['shaping'], 'toggle_hide(\'shaping1\', \'hidden\'); toggle_hide(\'shaping2\', \'hidden\')'), 
    new pref_numeric(user_levels::CONFIG_LEVEL_MASTER, $LN['config_maxdl'], 'maxdl', $LN['config_maxdl_msg'], $maxdl_msg, $prefArray_root['maxdl'], NUMBER_BOX_SIZE, NULL, 'shaping1', $prefArray_root['shaping'] ? NULL : 'hidden'), 
    new pref_numeric(user_levels::CONFIG_LEVEL_MASTER, $LN['config_maxul'], 'maxul', $LN['config_maxul_msg'], $maxul_msg, $prefArray_root['maxul'], NUMBER_BOX_SIZE, NULL, 'shaping2', $prefArray_root['shaping'] ? NULL : 'hidden'), 
);


$ext_progs = array(
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_urdd'], 'urdd_path', $LN['config_urdd_msg'], $urdd_path_msg, $prefArray_root['urdd_path'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_yydecode'], 'yydecode_path', $LN['config_yydecode_msg'], $yydecode_path_msg, $prefArray_root['yydecode_path'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_yyencode'], 'yyencode_path', $LN['config_yyencode_msg'], $yyencode_path_msg, $prefArray_root['yyencode_path'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_par2'], 'unpar_path', $LN['config_par2_msg'], $unpar_path_msg, $prefArray_root['unpar_path'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_unrar'], 'unrar_path', $LN['config_unrar_msg'], $unrar_path_msg, $prefArray_root['unrar_path'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_rar'], 'rar_path', $LN['config_rar_msg'], $rar_path_msg, $prefArray_root['rar_path'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_unace'], 'unace_path', $LN['config_unace_msg'], $unace_path_msg, $prefArray_root['unace_path'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_un7zr'], 'un7zr_path', $LN['config_un7zr_msg'], $un7zr_path_msg, $prefArray_root['un7zr_path'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_unzip'], 'unzip_path', $LN['config_unzip_msg'], $unzip_path_msg, $prefArray_root['unzip_path'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_gzip'], 'gzip_path', $LN['config_gzip_msg'], $gzip_path_msg, $prefArray_root['gzip_path'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_unarj'], 'unarj_path', $LN['config_unarj_msg'], $unarj_path_msg, $prefArray_root['unarj_path'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_file'], 'file_path', $LN['config_file_msg'], $file_path_msg, $prefArray_root['file_path'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_tar'], 'tar_path', $LN['config_tar_msg'], $tar_path_msg, $prefArray_root['tar_path'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_cksfv'], 'cksfv_path', $LN['config_cksfv_msg'], $cksfv_path_msg, $prefArray_root['cksfv_path'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_trickle'], 'trickle_path', $LN['config_trickle_msg'], $trickle_path_msg, $prefArray_root['trickle_path'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_subdownloader'], 'subdownloader_path', $LN['config_subdownloader_msg'], $subdownloader_path_msg, $prefArray_root['subdownloader_path'], TEXT_BOX_SIZE));


$prog_params = array(
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_urdd_pars'], 'urdd_pars', $LN['config_urdd_pars_msg'], $urdd_pars_msg, $prefArray_root['urdd_pars'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_yydecode_pars'], 'yydecode_pars', $LN['config_yydecode_pars_msg'], $yydecode_pars_msg, $prefArray_root['yydecode_pars'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_yyencode_pars'], 'yyencode_pars', $LN['config_yyencode_pars_msg'], $yyencode_pars_msg, $prefArray_root['yyencode_pars'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_par2_pars'], 'unpar_pars', $LN['config_par2_pars_msg'], $unpar_pars_msg, $prefArray_root['unpar_pars'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_unrar_pars'], 'unrar_pars', $LN['config_unrar_pars_msg'], $unrar_pars_msg, $prefArray_root['unrar_pars'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_rar_pars'], 'rar_pars', $LN['config_rar_pars_msg'], $rar_pars_msg, $prefArray_root['rar_pars'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_unace_pars'], 'unace_pars', $LN['config_unace_pars_msg'], $unace_pars_msg, $prefArray_root['unace_pars'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_un7zr_pars'], 'un7zr_pars', $LN['config_un7zr_pars_msg'], $un7zr_pars_msg, $prefArray_root['un7zr_pars'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_unzip_pars'], 'unzip_pars', $LN['config_unzip_pars_msg'], $unzip_pars_msg, $prefArray_root['unzip_pars'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_gzip_pars'], 'gzip_pars', $LN['config_gzip_pars_msg'], $gzip_pars_msg, $prefArray_root['gzip_pars'], TEXT_BOX_SIZE),
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_unarj_pars'], 'unarj_pars', $LN['config_unarj_pars_msg'], $unarj_pars_msg, $prefArray_root['unarj_pars'], TEXT_BOX_SIZE), 
    new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_subdownloader_pars'], 'subdownloader_pars', $LN['config_subdownloader_pars_msg'], $unarj_pars_msg, $prefArray_root['subdownloader_pars'], TEXT_BOX_SIZE),);

// we show this one if URDD is offline
$maintenance_offline = array(
    new pref_plain(user_levels::CONFIG_LEVEL_BASIC, $LN['urdddisabled'], $LN['urdddisabled'], $LN['enableurddfirst'], NULL, NULL)
);

// Maintenance  options
$maintenance[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_checkupdate'], $LN['config_checkupdate_msg'], $update_msg, 'period_update', $prefArray_root['period_update'], 'time1_update', $prefArray_root['time1_update'], 'time2_update', $prefArray_root['time2_update']);

$maintenance[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_optimisedb'], $LN['config_optimisedb_msg'], $optimise_msg, 'period_opt', $prefArray_root['period_opt'], 'time1_opt', $prefArray_root['time1_opt'], 'time2_opt', $prefArray_root['time2_opt']);
if ($module_config[urd_modules::URD_CLASS_GROUPS]) {
    $maintenance[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_updatenglist'], $LN['config_updatenglist_msg'], $nglist_msg, 'period_ng', $prefArray_root['period_ng'], 'time1_ng', $prefArray_root['time1_ng'], 'time2_ng', $prefArray_root['time2_ng']);
}
$maintenance[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_cleanusers'], $LN['config_cleanusers_msg'], $cleanusers_msg, 'period_cu', $prefArray_root['period_cu'], 'time1_cu', $prefArray_root['time1_cu'], 'time2_cu', $prefArray_root['time2_cu']);
$maintenance[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_users_clean_age'], 'users_clean_age', $LN['config_users_clean_age_msg'], $users_clean_age_msg, $prefArray_root['users_clean_age'], NUMBER_BOX_SIZE);
$maintenance[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_cleandir'], $LN['config_cleandir_msg'], $cleandir_msg, 'period_cd', $prefArray_root['period_cd'], 'time1_cd', $prefArray_root['time1_cd'], 'time2_cd', $prefArray_root['time2_cd'], 'dir_cd', $cleandir_dirs, $prefArray_root['dir_cd']);
$maintenance[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_clean_dir_age'], 'clean_dir_age', $LN['config_clean_dir_age_msg'], $clean_dir_age_msg, $prefArray_root['clean_dir_age'], NUMBER_BOX_SIZE);
$maintenance[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_cleandb'], $LN['config_cleandb_msg'], $cleandb_msg, 'period_cdb', $prefArray_root['period_cdb'], 'time1_cdb', $prefArray_root['time1_cdb'], 'time2_cdb', $prefArray_root['time2_cdb']);
$maintenance[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_clean_db_age'], 'clean_db_age', $LN['config_clean_db_age_msg'], $clean_db_age_msg, $prefArray_root['clean_db_age'], NUMBER_BOX_SIZE);

if ($module_config[urd_modules::URD_CLASS_SYNC]) {
    $maintenance[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_sendinfo'], $LN['config_sendinfo_msg'], $sendinfo_msg, 'period_sendinfo', $prefArray_root['period_sendinfo'], 'time1_sendinfo', $prefArray_root['time1_sendinfo'], 'time2_sendinfo', $prefArray_root['time2_sendinfo']);
    $maintenance[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_getinfo'], $LN['config_getinfo_msg'], $getinfo_msg, 'period_getinfo', $prefArray_root['period_getinfo'], 'time1_getinfo', $prefArray_root['time1_getinfo'], 'time2_getinfo', $prefArray_root['time2_getinfo']);
}

// Global settings
$global_settings[] = new pref_select(user_levels::CONFIG_LEVEL_ALWAYS, $LN['pref_level'], 'pref_level', $LN['pref_level_msg'], '', $levels, $pref_level, 'onchange="submit_config()"');
$global_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_defaultlanguage'], 'default_language', $LN['config_defaultlanguage_msg'], $default_language_msg, $languages, $prefArray_root['default_language']);

$global_settings[] = new pref_select(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_defaulttemplate'], 'default_template', $LN['config_defaulttemplate_msg'], $default_template_msg, $templates, $prefArray_root['default_template']);
$global_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_defaultstylesheet'], 'default_stylesheet', $LN['config_defaultstylesheet_msg'], $default_stylesheet_msg, $stylesheets, $prefArray_root['default_stylesheet']);
$global_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_log_level'], 'log_level', $LN['config_log_level_msg'], $log_level_msg, $log_levels, $prefArray_root['log_level']);
$global_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['pref_index_page'], 'index_page_root', $LN['pref_index_page_msg'], $index_page_msg, $index_page_array, $prefArray_root['index_page_root']);

$global_settings[] = new pref_select(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_permissions'], 'permissions', $LN['config_permissions_msg'], $permissions_msg, $permissions, $prefArray_root['permissions']);
$global_settings[] = new pref_select(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_group'], 'group', $LN['config_group_msg'], $group_msg, $groups, $prefArray_root['group']);
$global_settings[] = new pref_numeric_noformat(user_levels::CONFIG_LEVEL_MASTER, $LN['config_maxbuttons'], 'maxbuttons', $LN['config_maxbuttons_msg'], $maxbuttons_msg, $prefArray_root['maxbuttons'], NUMBER_BOX_SIZE);
if ($module_config[urd_modules::URD_CLASS_DOWNLOAD]) {
    $global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_global_scripts'], 'allow_global_scripts', $LN['config_global_scripts_msg'], $global_scripts_msg, $prefArray_root['allow_global_scripts'], 'toggle_hide(\'hide_userscripts\', \'hidden\')');
    $global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_user_scripts'], 'allow_user_scripts', $LN['config_user_scripts_msg'], $user_scripts_msg, $prefArray_root['allow_user_scripts'], NULL, 'hide_userscripts', $prefArray_root['allow_global_scripts'] == 1 ? NULL : 'hidden');
    $global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_auto_download'], 'auto_download', $LN['config_auto_download_msg'], $auto_download_msg, $prefArray_root['auto_download']);
}
$notify_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_BASIC, $LN['config_sendmail'], 'sendmail', $LN['config_sendmail_msg'], $sendmail_msg, $prefArray_root['sendmail'], 'toggle_hide(\'hide_maa\', \'hidden\');toggle_hide(\'hide_macta\', \'hidden\');toggle_hide(\'hide_mad\', \'hidden\');toggle_hide(\'hide_mds\', \'hidden\');toggle_hide(\'hide_mnis\', \'hidden\');toggle_hide(\'hide_mnp\', \'hidden\');toggle_hide(\'hide_mnu\', \'hidden\');toggle_hide(\'hide_mpr\', \'hidden\');');

$notify_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_mail_account_activated'], 'mail_account_activated', $LN['config_mail_account_activated_msg'], $mail_account_activated_msg, $mail_templates, $prefArray_root['mail_account_activated'], NULL, 'hide_maa',  $prefArray_root['sendmail'] == 1 ? NULL:'hidden' );
$notify_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_mail_activate_account'], 'mail_activate_account', $LN['config_mail_activate_account_msg'], $mail_activate_account_msg, $mail_templates, $prefArray_root['mail_activate_account'], NULL, 'hide_macta',  $prefArray_root['sendmail'] == 1 ? NULL:'hidden' );
$notify_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_mail_account_disabled'], 'mail_account_disabled', $LN['config_mail_account_disabled_msg'], $mail_account_disabled_msg, $mail_templates, $prefArray_root['mail_account_disabled'], NULL, 'hide_mad',  $prefArray_root['sendmail'] == 1 ? NULL:'hidden' );
$notify_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_mail_download_status'], 'mail_download_status', $LN['config_mail_download_status_msg'], $mail_download_status_msg, $mail_templates, $prefArray_root['mail_download_status'], NULL, 'hide_mds',  $prefArray_root['sendmail'] == 1 ? NULL:'hidden' );
$notify_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_mail_new_interesting_sets'], 'mail_new_interesting_sets', $LN['config_mail_new_interesting_sets_msg'], $mail_new_interesting_sets_msg, $mail_templates, $prefArray_root['mail_new_interesting_sets'], NULL, 'hide_mnis',  $prefArray_root['sendmail'] == 1 ? NULL:'hidden' );
$notify_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_mail_new_preferences'], 'mail_new_preferences', $LN['config_mail_new_preferences_msg'], $mail_new_preferences_msg, $mail_templates, $prefArray_root['mail_new_preferences'], NULL, 'hide_mnp',  $prefArray_root['sendmail'] == 1 ? NULL:'hidden' );
$notify_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_mail_new_user'], 'mail_new_user', $LN['config_mail_new_user_msg'], $mail_new_user_msg, $mail_templates, $prefArray_root['mail_new_user'], NULL, 'hide_mnu',  $prefArray_root['sendmail'] == 1 ? NULL:'hidden' );
$notify_settings[] = new pref_select(user_levels::CONFIG_LEVEL_BASIC, $LN['config_mail_password_reset'], 'mail_password_reset', $LN['config_mail_password_reset_msg'], $mail_password_reset_msg, $mail_templates, $prefArray_root['mail_password_reset'], NULL, 'hide_mpr',  $prefArray_root['sendmail'] == 1 ? NULL:'hidden' );

$global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_MASTER, $LN['config_parse_nfo'], 'parse_nfo', $LN['config_parse_nfo_msg'], $parse_nfo_msg, $prefArray_root['parse_nfo']);
$global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_MASTER, $LN['config_clickjack'], 'clickjack', $LN['config_clickjack_msg'], $clickjack_msg, $prefArray_root['clickjack']);
$global_settings[] = new pref_numeric_noformat(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_max_login_count'], 'max_login_count', $LN['config_max_login_count_msg'], $max_login_count_msg, $prefArray_root['max_login_count'], NUMBER_BOX_SIZE);
$global_settings[] = new pref_select(user_levels::CONFIG_LEVEL_MASTER, $LN['config_auto_login'], 'auto_login', $LN['config_auto_login_msg'], $auto_login_msg, $users, $prefArray_root['auto_login']);

if ($module_config[urd_modules::URD_CLASS_VIEWFILES]) {
    $global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_BASIC, $LN['config_webdownload'], 'webdownload', $LN['config_webdownload_msg'], $webdownload_msg, $prefArray_root['webdownload']);
    $global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_webeditfile'], 'webeditfile', $LN['config_webeditfile_msg'], $webeditfile_msg, $prefArray_root['webeditfile']);
    $global_settings[] = new pref_numeric(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_maxfilesize'], 'maxfilesize', $LN['config_maxfilesize_msg'], $maxfilesize_msg, $prefArray_root['maxfilesize'], NUMBER_BOX_SIZE);
    $global_settings[] = new pref_numeric(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_maxpreviewsize'], 'maxpreviewsize', $LN['config_maxpreviewsize_msg'], $maxpreviewsize_msg, $prefArray_root['maxpreviewsize'], NUMBER_BOX_SIZE);
    $global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['hiddenfiles'], 'global_hiddenfiles', $LN['hiddenfiles_msg'], $hiddenfiles_msg, $prefArray_root['global_hiddenfiles'], 'toggle_hide(\'hidfil\', \'hidden\')');
    $global_settings[] = new pref_textarea(user_levels::CONFIG_LEVEL_ADVANCED, $LN['hidden_files_list'], 'global_hidden_files_list', $LN['hidden_files_list_msg'], $hidden_files_list_msg, $hidden_files_list, 10, 40, NULL, 'hidfil', $prefArray_root['global_hiddenfiles'] ? NULL : 'hidden');
    $global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_compress_nzb'], 'compress_nzb', $LN['config_compress_nzb_msg'], $compress_nzb_msg, $prefArray_root['compress_nzb']);
}
if ($module_config[urd_modules::URD_CLASS_DOWNLOAD] || $module_config[urd_modules::URD_CLASS_MAKENZB] || $module_config[urd_modules::URD_CLASS_USENZB]) {
    $global_settings[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_replacement_str'], 'replacement_str', $LN['config_replacement_str_msg'], $replacement_str_msg, $prefArray_root['replacement_str'], TEXT_BOX_SIZE);
}

$global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_MASTER, $LN['config_allow_robots'], 'allow_robots', $LN['config_allow_robots_msg'], $allow_robots_msg, $prefArray_root['allow_robots']);
$global_settings[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_register'], 'register', $LN['config_register_msg'], $register_msg, $prefArray_root['register'], 'toggle_hide(\'auto_reg_tr\', \'hidden\'); toggle_value(\'register\')');
$global_settings[] =  new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_autoaccept'], 'auto_reg', $LN['config_autoaccept_msg'], $auto_reg_msg, $prefArray_root['auto_reg'], NULL, 'auto_reg_tr', $prefArray_root['register'] ? '' : 'hidden');

$set_updating= array();
$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_extset_group'], 'extset_group', $LN['config_extset_group_msg'], $extset_group_msg, $prefArray_root['extset_group'], TEXT_BOX_SIZE);
$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_spots_group'], 'spots_group', $LN['config_spots_group_msg'], $spots_group_msg, $prefArray_root['spots_group'], TEXT_BOX_SIZE);
$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_spots_reports_group'], 'spots_reports_group', $LN['config_spots_reports_group_msg'], $spots_reports_group_msg, $prefArray_root['spots_reports_group'], TEXT_BOX_SIZE);
$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_spots_comments_group'], 'spots_comments_group', $LN['config_spots_comments_group_msg'], $spots_comments_group_msg, $prefArray_root['spots_comments_group'], TEXT_BOX_SIZE);
$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_ftd_group'], 'ftd_group', $LN['config_ftd_group_msg'], $ftd_group_msg, $prefArray_root['ftd_group'], TEXT_BOX_SIZE);
$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_spots_blacklist'], 'spots_blacklist', $LN['config_spots_blacklist_msg'], $spots_blacklist_msg, $prefArray_root['spots_blacklist'], TEXT_BOX_SIZE);
$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_BASIC, $LN['config_spots_whitelist'], 'spots_whitelist', $LN['config_spots_whitelist_msg'], $spots_whitelist_msg, $prefArray_root['spots_whitelist'], TEXT_BOX_SIZE);
if ($module_config[urd_modules::URD_CLASS_GROUPS]) {
    $set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_group_filter'], 'group_filter', $LN['config_group_filter_msg'], $group_filter_msg, $prefArray_root['group_filter'], TEXT_BOX_SIZE);
}

$set_updating[] = new pref_checkbox(user_levels::CONFIG_LEVEL_BASIC, $LN['config_expafterupdate'], 'auto_expire', $LN['config_expafterupdate_msg'], $auto_expire_msg, $prefArray_root['auto_expire']); 
if ($module_config[urd_modules::URD_CLASS_GROUPS] || $module_config[urd_modules::URD_CLASS_RSS]) {
    $set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_maxexpire'], 'maxexpire', $LN['config_maxexpire_msg'], $maxexpire_msg, $prefArray_root['maxexpire'], NUMBER_BOX_SIZE);
}
if ($module_config[urd_modules::URD_CLASS_SPOTS]) {
    $set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_spots_expire'], 'spots_expire_time', $LN['config_spots_expire_msg'], $spots_expire_time_msg, $prefArray_root['spots_expire_time'], NUMBER_BOX_SIZE); 
}
$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_expire'], 'default_expire_time', $LN['config_expire_msg'], $default_expire_time_msg, $prefArray_root['default_expire_time'], NUMBER_BOX_SIZE); 
$set_updating[] = new pref_numeric_noformat(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_total_max_articles'], 'total_max_articles', $LN['config_total_max_articles_msg'], $total_max_articles_msg, $prefArray_root['total_max_articles'], NUMBER_BOX_SIZE); 

if ($module_config[urd_modules::URD_CLASS_GROUPS] || $module_config[urd_modules::URD_CLASS_RSS]) {
    $set_updating[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_keep_int'], 'keep_interesting', $LN['config_keep_int_msg'], $keep_int_msg, $prefArray_root['keep_interesting']);
}
if ($module_config[urd_modules::URD_CLASS_SPOTS]) {
    $set_updating[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_get_spots'], $LN['config_get_spots_msg'], $getspots_msg, 'period_getspots', $prefArray_root['period_getspots'], 'time1_getspots', $prefArray_root['time1_getspots'], 'time2_getspots', $prefArray_root['time2_getspots']);
    $set_updating[] = new pref_checkbox(user_levels::CONFIG_LEVEL_BASIC, $LN['config_download_spots_reports'], 'download_spots_reports', $LN['config_download_spots_reports_msg'], $download_spots_reports_msg, $prefArray_root['download_spots_reports']); 
    $set_updating[] = new pref_checkbox(user_levels::CONFIG_LEVEL_BASIC, $LN['config_download_spots_images'], 'download_spots_images', $LN['config_download_spots_images_msg'], $download_spots_images_msg, $prefArray_root['download_spots_images']); 
    $set_updating[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_download_spots_comments'], 'download_spots_comments', $LN['config_download_spots_comments_msg'], $download_spots_comments_msg, $prefArray_root['download_spots_comments']); 
    $set_updating[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_get_spots_blacklist'], $LN['config_get_spots_blacklist_msg'], $getspots_blacklist_msg, 'period_getspots_blacklist', $prefArray_root['period_getspots_blacklist'], 'time1_getspots_blacklist', $prefArray_root['time1_getspots_blacklist'], 'time2_getspots_blacklist', $prefArray_root['time2_getspots_blacklist']);
    $set_updating[] = new pref_period(user_levels::CONFIG_LEVEL_BASIC, $LN['config_get_spots_whitelist'], $LN['config_get_spots_whitelist_msg'], $getspots_whitelist_msg, 'period_getspots_whitelist', $prefArray_root['period_getspots_whitelist'], 'time1_getspots_whitelist', $prefArray_root['time1_getspots_whitelist'], 'time2_getspots_whitelist', $prefArray_root['time2_getspots_whitelist']);
}

$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_expire_incomplete'], 'expire_incomplete', $LN['config_expire_incomplete_msg'], $expire_incomplete_msg, $prefArray_root['expire_incomplete'], NUMBER_BOX_SIZE); 
$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_expire_percentage'], 'expire_percentage', $LN['config_expire_percentage_msg'], $expire_percentage_msg, $prefArray_root['expire_percentage'], NUMBER_BOX_SIZE);

$set_updating[] = new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['config_maxheaders'], 'maxheaders', $LN['config_maxheaders_msg'], $maxheaders_msg, $prefArray_root['maxheaders'], NUMBER_BOX_SIZE);
$set_updating[] = new pref_checkbox(user_levels::CONFIG_LEVEL_BASIC, $LN['config_autogetnfo'], 'auto_getnfo', $LN['config_autogetnfo_msg'], $auto_getnfo_msg, $prefArray_root['auto_getnfo'], 'toggle_hide(\'follow_link_tr\', \'hidden\')'); 
$set_updating[] = new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_follow_link'], 'follow_link', $LN['config_follow_link_msg'], $follow_link_msg, $prefArray_root['follow_link'], NULL, 'follow_link_tr', $prefArray_root['auto_getnfo'] ? '' : 'hidden');
$set_updating[] = new pref_textarea (user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_poster_blacklist'], 'poster_blacklist',$LN['config_poster_blacklist_msg'], '', utf8_decode($poster_blacklist), 10, 40);

$modules = array(
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_module_groups'], 'module[' . urd_modules::URD_CLASS_GROUPS . ']', $LN['config_module_groups_msg'], $module_msg[urd_modules::URD_CLASS_GROUPS], $module_config[urd_modules::URD_CLASS_GROUPS]),
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_module_usenzb'], 'module[' . urd_modules::URD_CLASS_USENZB . ']', $LN['config_module_usenzb_msg'], $module_msg[urd_modules::URD_CLASS_USENZB], $module_config[urd_modules::URD_CLASS_USENZB]),
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_module_spots'], 'module[' . urd_modules::URD_CLASS_SPOTS . ']', $LN['config_module_spots_msg'], $module_msg[urd_modules::URD_CLASS_SPOTS], $module_config[urd_modules::URD_CLASS_SPOTS]),
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_module_makenzb'], 'module[' . urd_modules::URD_CLASS_MAKENZB . ']', $LN['config_module_makenzb_msg'], $module_msg[urd_modules::URD_CLASS_MAKENZB], $module_config[urd_modules::URD_CLASS_MAKENZB]), 
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_module_rss'], 'module[' . urd_modules::URD_CLASS_RSS . ']', $LN['config_module_rss_msg'], $module_msg[urd_modules::URD_CLASS_RSS], $module_config[urd_modules::URD_CLASS_RSS]), 
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_module_post'], 'module[' . urd_modules::URD_CLASS_POST . ']', $LN['config_module_post_msg'], $module_msg[urd_modules::URD_CLASS_POST], $module_config[urd_modules::URD_CLASS_POST]),
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_module_sync'], 'module[' . urd_modules::URD_CLASS_SYNC . ']', $LN['config_module_sync_msg'], $module_msg[urd_modules::URD_CLASS_SYNC], $module_config[urd_modules::URD_CLASS_SYNC]),
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_module_download'], 'module[' . urd_modules::URD_CLASS_DOWNLOAD . ']', $LN['config_module_download_msg'], $module_msg[urd_modules::URD_CLASS_DOWNLOAD], $module_config[urd_modules::URD_CLASS_DOWNLOAD]),
    new pref_checkbox(user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_module_viewfiles'], 'module[' . urd_modules::URD_CLASS_VIEWFILES . ']', $LN['config_module_viewfiles_msg'], $module_msg[urd_modules::URD_CLASS_VIEWFILES], $module_config[urd_modules::URD_CLASS_VIEWFILES]),);

$format_strings = array();
foreach ($SETTYPES as $t) {
    $format_strings[] = new pref_text(user_levels::CONFIG_LEVEL_MASTER, $LN['settype'][$t], "settype_$t", $LN['settype_msg'][$t], $settype_msg[$t], $prefArray_root["settype_$t"], TEXT_BOX_SIZE);
}


$pref_list[] = new pref_list('config_globalsettings', $global_settings);
$pref_list[] = new pref_list('config_notifysettings', $notify_settings);
$pref_list[] = new pref_list('config_urdd_head', $urdd_cfg);
$pref_list[] = new pref_list('config_networking', $networking);
$pref_list[] = new pref_list('config_setinfo', $set_updating);
$pref_list[] = new pref_list('config_formatstrings', $format_strings);
$pref_list[] = new pref_list('config_extprogs', $ext_progs);
$pref_list[] = new pref_list('config_prog_params', $prog_params);
$pref_list[] = new pref_list('config_modules', $modules);
if ($URDDONLINE) {
    $pref_list[] = new pref_list('config_maintenance', $maintenance);
} else {
    $pref_list[] = new pref_list('config_maintenance', $maintenance_offline);
}

init_smarty($LN['config_title'], 1, $add_menu);
$smarty->assign('level', $pref_level);
$smarty->assign('saved', $saved);
$smarty->assign('imported', $imported);
$smarty->assign('__message', $__message);
$smarty->assign('active_page', str_replace(' ', '', get_post('current_tab', 'config_globalsettings')));
$smarty->assign('pref_list', $pref_list);

$smarty->assign('referrer', basename(__FILE__, '.php'));
$smarty->display('settings.tpl');



