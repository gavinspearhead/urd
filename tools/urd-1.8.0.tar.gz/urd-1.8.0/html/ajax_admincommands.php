<?php
/*
 *  This file is part of Urd.
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2012-05-13 19:08:30 +0200 (zo, 13 mei 2012) $
 * $Rev: 2514 $
 * $Author: gavinspearhead $
 * $Id: ajax_admincommands.php 2514 2012-05-13 17:08:30Z gavinspearhead $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);
$__auth = 'silent';

$pathad = realpath(dirname(__FILE__));

require_once "$pathad/../functions/ajax_includes.php";
require_once "$pathad/../functions/pref_functions.php";

verify_access($db, NULL, TRUE, '', $userID,  TRUE);

// Process commands:
// Needs to be updated for Urdd:
if (isset($_POST['action'])) {
	$prefs = load_config($db);
	$action = get_post('action');

	switch ($action) {
	case 'checkversion':
		$uc = new urdd_client($db, $prefs['urdd_host'], $prefs['urdd_port'], $userID);
		if ($uc->is_connected()) {
            $uc->check_version();
        }
		usleep(500000);
		break;
	case 'poweron' :
		start_urdd();
        break;
    case 'restart':
		$uc = new urdd_client($db, $prefs['urdd_host'], $prefs['urdd_port'], $userID);
		if ($uc->is_connected()) {
            $uc->restart_urdd();
        }
		usleep(500000);
		break;
	case 'shutdown' :
		stop_urdd($userID);
		break;

	case 'removeready' : 
		$uc = new urdd_client($db, $prefs['urdd_host'], $prefs['urdd_port'], $userID);
		if ($uc->is_connected()) {
            $uc->cleandb();
        }
		usleep(500000);
		break;
	case 'cleandb' : 
		$uc = new urdd_client($db, $prefs['urdd_host'], $prefs['urdd_port'], $userID);
		if ($uc->is_connected()) { 
            $uc->cleandb('all');
        }
		usleep(500000);
		break;
	case 'pause' : 
		$uc = new urdd_client($db, $prefs['urdd_host'], $prefs['urdd_port'], $userID);
		if ($uc->is_connected()) {
            $uc->pause('all');
        }
		usleep(500000);
		break;
	case 'continue' : 
		$uc = new urdd_client($db, $prefs['urdd_host'], $prefs['urdd_port'], $userID);
		if ($uc->is_connected()) {
            $uc->continue_cmd('all');
        }
		usleep(500000);
		break;
	case 'ratelimit': // XXX Not implemented yet
	default:
		die_html($LN['error_novalidaction']);
		break;
	}
}

die_html('OK');

