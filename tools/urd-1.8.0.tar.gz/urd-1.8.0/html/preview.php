<?php
/*
 *  This file is part of Urd.
 *
 *  vim:ts=4:expandtab:cindent
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2013-03-02 23:44:17 +0100 (za, 02 mrt 2013) $
 * $Rev: 2798 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: preview.php 2798 2013-03-02 22:44:17Z gavinspearhead@gmail.com $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);

$pathtr = realpath(dirname(__FILE__));

require_once "$pathtr/../functions/html_includes.php";

$dlid = get_request('dlid', 0);
$binary_id = get_request('binary_id', 0);
$group_id = get_request('group_id', 0);
$dl_name = get_download_name($db, $dlid);
$dl_size = get_download_size($db, $dlid);
list($size, $suffix) = format_size($dl_size, 'h', $LN['byte_short'], 1024);
$dl_size = $size . $suffix;

init_smarty($LN['preview_title'], 0);
$smarty->assign('dlid',	        $dlid);
$smarty->assign('dlname',	    $dl_name);
$smarty->assign('dl_size',	    $dl_size);
$smarty->assign('binary_id',    $binary_id);
$smarty->assign('group_id',	    $group_id);

$smarty->display('preview.tpl');


