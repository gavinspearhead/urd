<?php
/*
 *  This file is part of Urd.
 *  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2013-03-02 23:44:17 +0100 (za, 02 mrt 2013) $
 * $Rev: 2798 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: ajax_adminjobs.php 2798 2013-03-02 22:44:17Z gavinspearhead@gmail.com $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);

$__auth = 'silent';

$pathadt = realpath(dirname(__FILE__));

require_once "$pathadt/../functions/html_includes.php";
require_once "$pathadt/../functions/pref_functions.php";

verify_access($db, NULL, TRUE, '', $userID, TRUE);

$sort = get_request('sort', 'command');
$sort_dir = strtolower(get_request('sort_dir', 'desc'));

if (!in_array($sort, array('command', 'at_time', 'interval', 'username'))) {
    ajax_fatal_error('invalid sortname');
}
if (!in_array($sort_dir, array('asc', 'desc'))) {
    ajax_fatal_error('invalid sortname');
}

$qry = "* FROM schedule ORDER BY \"$sort\" $sort_dir";
$res = $db->select_query($qry);
$jobs = array();
if ($res === FALSE) {
    $res = array();
}

foreach ($res as $row){
	$job['time'] = time_format($row['at_time']);
	$job['period'] = readable_time($row['interval']);
	$description = command_description($db, $row['command']);
    $task_short = $description[0];
    $task_arg = $description[1];
	$job['user'] = $row['username'];
	$task_long = '';
	$job['cmd'] = $row['command'];
	$job['task'] = $task_short;
    $job['arg'] = $task_arg;
	$jobs[] = $job;
}


$urdd_online = check_urdd_online($db);
init_smarty('', 0);
$smarty->assign('alljobs',	$jobs);
$smarty->assign('sort',	$sort);
$smarty->assign('sort_dir',	$sort_dir);
$smarty->assign('urdd_online',    	(int)$urdd_online);
$smarty->display('ajax_adminjobs.tpl');



