<?php
/*
 *  This file is part of Urd.
 *  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2013-06-28 23:30:22 +0200 (vr, 28 jun 2013) $
 * $Rev: 2852 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: prefs.php 2852 2013-06-28 21:30:22Z gavinspearhead@gmail.com $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);


$pathpr = realpath(dirname(__FILE__));


require_once "$pathpr/../functions/html_includes.php";
require_once "$pathpr/../functions/pref_functions.php";

$languages = array_map('htmlentities', get_languages());

$cmd = get_post('cmd', '');

if ($cmd == 'submit_button') {
    challenge::verify_challenge($_POST['challenge']);

	$db->escape($_POST['language']); // Global escape.
    $language_msg = set_and_test_pref_array('language', $userID, array_keys($languages));
    if ($language_msg == '') {
        unset($LN);
        foreach($smarty->getTemplateVars() as $k=>$v) {
            if (substr($k, 0, 3) == 'LN_') {
                $smarty->clearAssign($k);
            }
        }
        load_language($_POST['language']);
    }
}

$searchbuttons = array();
try {
    foreach(get_buttons($db) as $k => $s) {
        $searchbuttons[$k] = htmlentities(utf8_decode($s));
    }
} catch (exception $e) {
    // don't do anything?
}
$level_array = user_levels::get_user_levels();

$templates = get_templates();

$search_type_array = array(
	'LIKE' => $LN['search_type_like'],
	'REGEXP' => $LN['search_type_regexp']
);


$basket_type_array = array(
	 basket_type::SMALL => $LN['basket_type_small'],
	 basket_type::LARGE => $LN['basket_type_large']
);
$encrar_array = array (
    encrar::ENCRAR_CONTINUE => $LN['continue'],
    encrar::ENCRAR_CANCEL   => $LN['cancel'],
    encrar::ENCRAR_PAUSE    => $LN['pause']
);


$spot_categories = SpotCategories::get_categories();
$categories = get_categories($db, $userID); 
$category_array[''] = '';
foreach($categories as $cat) {
    $category_array[$cat['id']] = $cat['name'];
}


$saved_searches = new saved_searches($userID);
$saved_searches->load($db);
$spot_array = $saved_searches->get_all_names(USERSETTYPE_SPOT);
$spot_array = array_merge(array('' => $LN['spots_allcategories']), $spot_array); 


$categories = get_used_categories_group($db, $userID);
$subscribedgroups = subscribed_groups_select($db, NULL, NULL, $categories,  $userID);
$subscribedfeeds = subscribed_feeds_select($db, NULL, NULL, $categories,  $userID);

$groups_array = array();
$groups_array["0"] = $LN['browse_allgroups'];
foreach($subscribedgroups as $ng) { 
    $id = $ng['id'];
    $name = $ng['shortname'];
    $type = $ng['type'];
    $idx = $type . '_' . $id;
    $groups_array[ $idx ] = $name;
}

$feeds_array = array();
$feeds_array["0"] = $LN['feeds_allgroups'];
foreach($subscribedfeeds as $ng) { 
    $id = $ng['id'];
    $name = $ng['name'];
    $type = $ng['type'];
    $idx = $type . '_' . $id;
    $feeds_array[ $idx ] = $name;
}


$add_menu = array (
    'actions'=> 
    array(
        new menu_item2 ('export_prefs','settings_export',urd_modules::URD_CLASS_GENERIC, '', 'command'),
        new menu_item2 ('import_prefs','settings_import',urd_modules::URD_CLASS_GENERIC, '', 'command'),
        new menu_item2 ('reset_prefs','reset',urd_modules::URD_CLASS_GENERIC, $LN['reset'] . ' ' . $LN['pref_title'] , 'command'),
    )
);


$stylesheets = get_stylesheets();

$imported = $saved = 0;
$sort_array = array(
	'better_subject ASC'  => $LN['browse_subject'] . ' - ' . $LN['ascending'],
	'better_subject DESC' => $LN['browse_subject'] . ' - ' . $LN['descending'],
	'Date DESC'           => $LN['browse_age'] . ' - ' . $LN['ascending'], // need to be inverted as we sort on timestamp, not age
	'Date ASC'            => $LN['browse_age'] . ' - ' . $LN['descending'],
	'Size ASC'            => $LN['size'] . ' - ' . $LN['ascending'],
	'Size DESC'           => $LN['size'] . ' - ' . $LN['descending']
);

$modules = urd_modules::get_urd_module_config( get_config($db, 'modules'));
$index_page_array = get_index_page_array($isadmin, $modules);

$dlpath = get_dlpath($db);
$scripts_path = $dlpath . SCRIPTS_PATH;


function get_scripts(DatabaseConnection $db, $dir, $username = '', $global = TRUE)
{
    if ($global === TRUE) {
        $scripts = get_pref($db, 'global_scripts', $username, '');
    } else {
        $scripts = get_pref($db, 'user_scripts', $username, '');
    }
    $scripts = explode("\n", $scripts);
	if ($global === TRUE) {
		$files = glob("$dir/*." . URDD_SCRIPT_EXT);
    } else {
        $files = glob("$dir/$username/*." . URDD_SCRIPT_EXT);
    }
	$filenames = array();
	sort($files);

	foreach ($files as $fn) {
		if ($fn == '') {
            continue;
        }
        $fn = basename($fn);
        $file['on'] = (int)in_array($fn, $scripts);
        $file['name'] = $fn;
        $file['id'] = $fn;
        $filenames[] = $file;
    }
    return $filenames;
}

$shaping_msg = $unrar_msg = $unpar_msg = $auto_expire_msg = $password_msg = $index_page_msg = $add_setname_msg = '';
$delete_files_msg = $urdd_restart_msg = $nntp_useauth_msg = $hiddenfiles_msg = $mail_user_msg = $download_text_file_msg = $download_par_msg = '';
$search_type_msg = $use_auto_download_nzb_msg = $use_auto_download_msg = $skip_int_msg = $delete_account_msg = $max_tasks1_msg = '';
$max_task2_msg = $mail_user_sets_msg = $show_image_msg = $show_subcats_msg = '';

foreach ($spot_categories as $sc) {
    $spot_category_msg[$sc] = '';
}
update_settings($db, $userID);

$sendmail = get_config($db, 'sendmail');
$auto_download = get_config($db, 'auto_download');
$allow_global_scripts = get_config($db, 'allow_global_scripts');
$allow_user_scripts= get_config($db, 'allow_user_scripts');
// Save changes:
if ($cmd == 'save_settings') {
    header('Content-Type: text/html/force-download');
    header("Content-Disposition: attachment; filename=urd_user_settings_$username.xml");
    $xml = new urd_xml_writer('php://output');
    $xml->write_user_settings($db, $userID);
    $xml->output_xml_data();
    die;
}

if ($cmd == 'load_settings' && isset ($_FILES['filename']['tmp_name'])) {
    challenge::verify_challenge($_POST['challenge']);
    $xml = new urd_xml_reader($_FILES['filename']['tmp_name']);
    $settings = $xml->read_user_settings($db);
    reset($settings);

    if ($settings != array()) {
        clean_pref($db, $userID); // remove all settings for user
        reset_pref($db, $userID); // restore the default settings
        set_prefs($db, $userID, current($settings)); // overwrite with loaded settings
    } else {
        $__message[] = $LN['settings_notfound'];
    }
}


if ($cmd == 'submit_button') {
    challenge::verify_challenge($_POST['challenge']);

    $db->escape($_POST); // Global escape.
    $mail_user_msg = set_and_test_pref_bool('mail_user', $userID, $foo);
    $show_image_msg = set_and_test_pref_bool('show_image', $userID, $foo);
    $show_subcats_msg = set_and_test_pref_bool('show_subcats', $userID, $foo);
    $add_setname_msg = set_and_test_pref_bool('add_setname', $userID, $foo);
    $mail_user_sets_msg = set_and_test_pref_bool('mail_user_sets', $userID, $foo);
    $use_auto_download_msg = set_and_test_pref_bool('use_auto_download', $userID, $foo);
    $use_auto_download_nzb_msg = set_and_test_pref_bool('use_auto_download_nzb', $userID, $foo);
    $download_text_file_msg = set_and_test_pref_bool('download_text_file', $userID, $foo);
    $spot_spam_limit_msg = set_and_test_pref_numeric('spot_spam_limit', $userID, 0, NULL, 1000);
    $maxsetname_msg = set_and_test_pref_numeric('maxsetname', $userID, 1, NULL, 1000);
    $minsetsize_msg = set_and_test_pref_numeric('minsetsize', $userID, 0, NULL, 1024, 'M');
    $maxsetsize_msg = set_and_test_pref_numeric('maxsetsize', $userID, 0, NULL, 1024, 'M');
    $minngsize_msg = set_and_test_pref_numeric('minngsize', $userID, 0, NULL, 1000);
    $download_delay_msg = set_and_test_pref_numeric('download_delay', $userID, 0, NULL, 1000);
    $rarfile_size_msg = set_and_test_pref_numeric('rarfile_size', $userID, 0, NULL, 1024, 'k');
    $recovery_size_msg = set_and_test_pref_numeric('recovery_size', $userID, 0, NULL, 1000);
    $setsperpage_msg = set_and_test_pref_numeric('setsperpage', $userID, 1, NULL, 1000);
    $setcompleteness_msg = set_and_test_pref_numeric('setcompleteness', $userID, 0, 100, 1000);
    $defaultsort_msg = set_and_test_pref_sort('defaultsort', $userID, array_keys($sort_array));
    $hidden_files_list_msg = set_and_test_pref_text_area('hidden_files_list', $userID, TRUE);
    $search_type_msg = set_and_test_pref_array('search_type', $userID, array_keys($search_type_array));
    $baskte_tyep_msg = set_and_test_pref_array('basket_type', $userID, array_keys($basket_type_array));
    $default_group_msg = set_and_test_pref_array('default_group', $userID, array_keys($groups_array));
    $default_spot_msg = set_and_test_pref_array('default_spot', $userID, array_keys($spot_array));
    $default_feed_msg = set_and_test_pref_array('default_feed', $userID, array_keys($feeds_array));
    $search_terms_msg = set_and_test_pref_text_area('search_terms', $userID, TRUE);
    $blocked_terms_msg = set_and_test_pref_text_area('blocked_terms', $userID, TRUE);
    $poster_name_msg = set_and_test_pref_text('poster_name', $userID, NULL, TRUE);
    $format_dl_dir_msg = set_and_test_pref_text('format_dl_dir', $userID, NULL, TRUE);
    $poster_email_msg = set_and_test_pref_text('poster_email', $userID, NULL, TRUE);
    $subs_lang_msg = set_and_test_pref_text('subs_lang', $userID, NULL, TRUE);
    $cancel_crypted_rars_msg = set_and_test_pref_array('cancel_crypted_rars', $userID, array_keys($encrar_array));

    try {
        if ($search_terms_msg == '') {
            sets_marking::mark_search($db,USERSETTYPE_GROUP, $userID, 'statusint', NULL);
            sets_marking::mark_search($db,USERSETTYPE_RSS, $userID, 'statusint', NULL);
            sets_marking::mark_search($db,USERSETTYPE_SPOT, $userID, 'statusint', NULL);
        }
        if ($blocked_terms_msg == '') {
            sets_marking::mark_search($db,USERSETTYPE_GROUP, $userID, 'statuskill', NULL);
            sets_marking::mark_search($db,USERSETTYPE_RSS, $userID, 'statuskill', NULL);
            sets_marking::mark_search($db,USERSETTYPE_SPOT, $userID, 'statuskill', NULL);
        }
    } catch (exception $e) {
        $__message[] = $e->getmessage();
    }
    
    foreach ($spot_categories as $sc) {
        $spot_category_msg[$sc] = set_and_test_pref_array('spot_category_' . $sc, $userID, array_keys($category_array));
    }

    $delete_files_msg = set_and_test_pref_bool('delete_files', $userID, $foo);
    $unrar_msg = set_and_test_pref_bool('unrar', $userID, $foo);
    $skip_int_msg = set_and_test_pref_bool('skip_int', $userID, $foo);
    $hiddenfiles_msg = set_and_test_pref_bool('hiddenfiles', $userID, $foo);
    $unpar_msg = set_and_test_pref_bool('unpar', $userID, $foo);
    $download_par_msg = set_and_test_pref_bool('download_par', $userID, $foo);
    $buttons_msg = set_and_test_pref_buttons('buttons', $userID, $searchbuttons);
    $user_scripts_msg = set_and_test_pref_scripts($scripts_path . $username . '/', 'user_scripts', $userID);
    $global_scripts_msg = set_and_test_pref_scripts($scripts_path, 'global_scripts', $userID);
    $template_msg = set_and_test_pref_array('template', $userID, array_keys($templates));
    $stylesheet_msg = set_and_test_pref_array('stylesheet', $userID, array_keys($stylesheets));
    $pref_level_msg = set_and_test_pref_array('pref_level', $userID, array_keys($level_array));

    $index_page_msg = set_and_test_pref_array('index_page', $userID, array_keys($index_page_array));
    /// todo refresh page if template changed.

    $oldpass  = get_post('oldpass', '');
    $newpass1 = get_post('newpass1', '');
    $newpass2 = get_post('newpass2', '');
    if ($oldpass != '' && $newpass1 != '' && $newpass2 != '') {
        if ($newpass1 != $newpass2) {
            $password_msg = make_error_msg($LN['error_pwmatch'], 'Error');
        } else {
            if (($pmsg = verify_password($newpass1, $username)) === TRUE ) {
                try {
                    $salt = get_salt($db, $username);
                } catch(exception $e) {
                    $salt = '';
                }

                $oldpass = hash('sha256',  $salt . $oldpass . $salt);
                $res = $db->select_query("\"name\" FROM users WHERE \"ID\"='$userID' AND \"pass\" = '$oldpass'");
                if ($res === FALSE) {
                    $password_msg = make_error_msg($LN['error_pwincorrect']);
                } else {
                    set_password($db, $userID, $newpass1);
                    $salt = get_salt($db, $username);
                    $token = generate_password(8);
                    list($password, $md5pass) = hash_password($newpass1, $salt, $token);
                    $period = get_session('urd_period', 0);
                    $period = get_cookie('urd_period', $period);
                    $_SESSION['urd_pass'] = $password;
                    $_SESSION['urd_token'] = $token;
                    setcookie('urd_pass', $password, max(time() + 3600, $period));
                    setcookie('urd_token', $token, max(time() + 3600, $period));
                }
            } else {
                $password_msg = make_error_msg($pmsg);
            }
        }
    } elseif ($oldpass != '' && ($newpass1 != '' || $newpass2 != '')) {
        $password_msg = make_error_msg($LN['error_pwincorrect']);
    }
    $saved = 1;
} elseif ($cmd == 'reset') {
    challenge::verify_challenge($_POST['challenge']);
    reset_pref($db, $userID);
}

// First, we get the current values:

$prefArray = load_prefs($db, $userID, TRUE);
$module_config = urd_modules::get_urd_module_config(get_config($db, 'modules'));

$global_scripts_array = get_scripts($db, $scripts_path, $username, TRUE);
$user_scripts_array = get_scripts($db, $scripts_path, $username, FALSE);

// test if the current settings are correct
if (!isset($default_spot_msg)) {
    $default_spot_msg = verify_array($prefArray['default_spot'], array_keys($spot_array));
}
if (!isset($cancel_crypted_rars_msg)) {
    $cancel_crypted_rars_msg = verify_array($prefArray['cancel_crypted_rars'], array_keys($encrar_array));
}
if (!isset($default_group_msg)) {
    $default_group_msg = verify_array($prefArray['default_group'], array_keys($groups_array));
}
if (!isset($default_feed_msg)) {
    $default_feed_msg = verify_array($prefArray['default_feed'], array_keys($feeds_array));
}
if (!isset($pref_level_msg)) {
    $pref_level_msg = verify_array($prefArray['pref_level'], array_keys($level_array));
}
if (!isset($language_msg)) {
    $language_msg = verify_array($prefArray['language'], array_keys($languages));
}
if (!isset($template_msg)) {
    $template_msg = verify_array($prefArray['template'], array_keys($templates));
}
if (!isset($stylesheet_msg)) {
    $stylesheet_msg = verify_array($prefArray['stylesheet'], array_keys($stylesheets));
}
if (!isset($index_array_msg)) {
    $index_array_msg = verify_array($prefArray['index_page'], array_keys($index_page_array));
}
if (!isset($search_type_msg)) {
    $search_type_msg = verify_array($prefArray['search_type'], array_keys($search_type_array));
}
if (!isset($basket_type_msg)) {
    $basket_type_msg = verify_array($prefArray['basket_type'], array_keys($basket_type_array));
}
if (!isset($search_terms_msg)) {
    $search_terms_msg = verify_text_area($prefArray['search_terms']);
}
if (!isset($blocked_terms_msg)) {
    $blocked_terms_msg = verify_text_area($prefArray['blocked_terms']);
}
if (!isset($hidden_files_list_msg)) {
    $hidden_files_list_msg = verify_text_area($prefArray['hidden_files_list']);
}
if (!isset($defaultsort_msg)) {
    $defaultsort_msg = verify_sort($prefArray['defaultsort'], array_keys($sort_array));
}
if (!isset($minsetsize_msg)) {
    $minsetsize_msg = verify_numeric($prefArray['minsetsize'],0, NULL, 1024, 'm');
}
if (!isset($maxsetsize_msg)) {
    $maxsetsize_msg = verify_numeric($prefArray['maxsetsize'],0, NULL, 1024, 'm');
}
if (!isset($minngsize_msg)) {
    $minngsize_msg = verify_numeric($prefArray['minngsize'],0, NULL, 1000);
}
if (!isset($spot_spam_limit_msg)) {
    $spot_spam_limit_msg = verify_numeric($prefArray['spot_spam_limit'],0, NULL, 1000);
}
if (!isset($setsperpage_msg)) {
    $setsperpage_msg = verify_numeric($prefArray['setsperpage'],1, NULL, 1000);
}
if (!isset($maxsetname_msg)) {
    $maxsetname_msg = verify_numeric($prefArray['maxsetname'],1, NULL, 1000);
}
if (!isset($download_delay_msg)) {
    $download_delay_msg = verify_numeric($prefArray['download_delay'],0, NULL, 1000);
}
if (!isset($recovery_size_msg)) {
    $recovery_size_msg = verify_numeric($prefArray['recovery_size'],0, NULL, 1000);
}
if (!isset($rarfile_size_msg)) {
    $rarfile_size_msg = verify_numeric($prefArray['rarfile_size'],0, NULL, 1000, 'k');
}

if (!isset($subs_lang_msg))  {
    $subs_lang_msg = verify_text_opt('subs_lang', TRUE, NULL);
}
if (!isset($poster_name_msg))  {
    $poster_name_msg = verify_text_opt('poster_name', TRUE, NULL);
}
if (!isset($format_dl_dir_msg))  {
    $format_dl_dir_msg = verify_text_opt('format_dl_dir', TRUE, NULL);
}
if (!isset($poster_email_msg))  {
    $poster_email_msg = verify_text_opt('poster_email', TRUE, NULL);
}
if (!isset($setcompleteness_msg)) {
    $setcompleteness_msg = verify_numeric($prefArray['setcompleteness'],0,100,1000);
}

if (!isset($global_scripts_msg)) {
    $global_scripts_msg = '';
}
if (!isset($user_scripts_msg)) {
    $user_scripts_msg = '';
}

if (!isset($buttons_msg)) {
    $buttons_msg = '';
    foreach($prefArray as $k => $p) {
        if (preg_match('/^button[0-9]+$/', $k) && $p != 'none') {
            $buttons_msg = verify_searchbutton($prefArray["$k"], $searchbuttons);
        }
    }
}

$cur_buttons = array();
foreach($prefArray as $k => $p) {
    if (preg_match('/^button[0-9]+$/', $k) && $p != 'none') {
        $cur_buttons[] = $p;
    }
}

$button_array = array();
foreach($searchbuttons as $k => $button) {
    $button_array[$k] = array('name'=>$button, 'on'=>0, 'id'=>$k);
}

foreach($cur_buttons as $b) {
    if (is_numeric($b) && isset($button_array[(int)$b])) {
        $button_array[(int)$b]['on'] = 1;
    }
}

$search_terms = ($prefArray['search_terms']);
$search_terms = clean_textarea_data($search_terms);
$search_terms = clean_list($search_terms);

$blocked_terms = ($prefArray['blocked_terms']);
$blocked_terms = clean_textarea_data($blocked_terms);
$blocked_terms = clean_list($blocked_terms);

$hidden_files_list = ($prefArray['hidden_files_list']);
$hidden_files_list = clean_textarea_data($hidden_files_list);
$hidden_files_list = clean_list($hidden_files_list);

$login = array(
        new pref_plain(user_levels::CONFIG_LEVEL_BASIC, $LN['username'],$LN['username_msg'],  $username, NULL, NULL),
        new pref_password(user_levels::CONFIG_LEVEL_BASIC, $LN['oldpw'], 'oldpass', $LN['oldpw_msg'] ,  $password_msg,'' , TEXT_BOX_SIZE),
        new pref_password(user_levels::CONFIG_LEVEL_BASIC, $LN['newpw'] . ' (1)', 'newpass1', $LN['newpw1_msg'] , '', '', TEXT_BOX_SIZE),
        new pref_password(user_levels::CONFIG_LEVEL_BASIC, $LN['newpw'] . ' (2)', 'newpass2', $LN['newpw2_msg'] , '', '', TEXT_BOX_SIZE),
        new pref_select(user_levels::CONFIG_LEVEL_BASIC,  $LN['pref_index_page'], 'index_page', $LN['pref_index_page_msg'], $index_page_msg,  $index_page_array, $prefArray['index_page']),
        new pref_button(user_levels::CONFIG_LEVEL_BASIC, $LN['delete_account'], 'delete_account', $LN['delete_account_msg'] , $delete_account_msg, $LN['delete'], 
            'onclick="javascript:confirm_delete_account(\'delete_account\', \'' . $LN['delete_account'] . '?\');"', 'delete_account', NULL),
        );

$display = array (
        new pref_select (user_levels::CONFIG_LEVEL_ALWAYS, $LN['pref_level'], 'pref_level',$LN['pref_level_msg'] ,$pref_level_msg, $level_array, $prefArray['pref_level'] ),
        new pref_select (user_levels::CONFIG_LEVEL_BASIC, $LN['pref_language'], 'language', $LN['pref_language_msg'], $language_msg, $languages, $prefArray['language']),
        new pref_select (user_levels::CONFIG_LEVEL_BASIC, $LN['pref_stylesheet'], 'stylesheet', $LN['pref_stylesheet_msg'], $stylesheet_msg, $stylesheets, $prefArray['stylesheet']),
        new pref_select (user_levels::CONFIG_LEVEL_ADVANCED, $LN['pref_template'], 'template', $LN['pref_template_msg'], $template_msg, $templates, $prefArray['template']),
        new pref_select (user_levels::CONFIG_LEVEL_BASIC, $LN['defaultsort'], 'defaultsort', $LN['defaultsort_msg'], $defaultsort_msg, $sort_array, $prefArray['defaultsort']),
        new pref_numeric (user_levels::CONFIG_LEVEL_BASIC, $LN['maxsetname'], 'maxsetname',$LN['maxsetname_msg'], $maxsetname_msg, $prefArray['maxsetname'], NUMBER_BOX_SIZE ),
        new pref_numeric (user_levels::CONFIG_LEVEL_BASIC, $LN['setsperpage'], 'setsperpage',$LN['setsperpage_msg'], $setsperpage_msg, $prefArray['setsperpage'], NUMBER_BOX_SIZE ),
        new pref_numeric (user_levels::CONFIG_LEVEL_BASIC, $LN['minsetsize'], 'minsetsize',$LN['minsetsize_msg'], $minsetsize_msg, $prefArray['minsetsize'], NUMBER_BOX_SIZE ),
        new pref_numeric (user_levels::CONFIG_LEVEL_BASIC, $LN['maxsetsize'], 'maxsetsize',$LN['maxsetsize_msg'], $maxsetsize_msg, $prefArray['maxsetsize'], NUMBER_BOX_SIZE ),
        new pref_numeric (user_levels::CONFIG_LEVEL_BASIC, $LN['minngsize'], 'minngsize',$LN['minngsize_msg'], $minngsize_msg, $prefArray['minngsize'], NUMBER_BOX_SIZE) ,
        new pref_numeric (user_levels::CONFIG_LEVEL_BASIC, $LN['pref_setcompleteness'], 'setcompleteness', $LN['pref_setcompleteness_msg'], $setcompleteness_msg,  $prefArray['setcompleteness'], NUMBER_BOX_SIZE),
        new pref_numeric (user_levels::CONFIG_LEVEL_ADVANCED, $LN['spot_spam_limit'], 'spot_spam_limit',$LN['spot_spam_limit_msg'], $spot_spam_limit_msg, $prefArray['spot_spam_limit'], NUMBER_BOX_SIZE ),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['show_image'], 'show_image', $LN['show_image_msg'], $show_image_msg, $prefArray['show_image']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['show_subcats'], 'show_subcats', $LN['show_subcats_msg'], $show_subcats_msg, $prefArray['show_subcats']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_ADVANCED, $LN['skip_int'], 'skip_int',$LN['skip_int_msg'], $skip_int_msg, $prefArray['skip_int']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_ADVANCED, $LN['hiddenfiles'], 'hiddenfiles',$LN['hiddenfiles_msg'], $hiddenfiles_msg, $prefArray['hiddenfiles'], 'toggle_hide(\'hidfil\', \'hidden\');'),
        new pref_textarea (user_levels::CONFIG_LEVEL_ADVANCED, $LN['hidden_files_list'], 'hidden_files_list',$LN['hidden_files_list_msg'], $hidden_files_list_msg, $hidden_files_list, 10, 40, NULL, 'hidfil', $prefArray['hiddenfiles']? NULL : 'hidden'),
        new pref_multiselect (user_levels::CONFIG_LEVEL_BASIC, $LN['buttons'], 'buttons[]',$LN['buttons_msg'], $buttons_msg, $button_array, 5),
        new pref_select (user_levels::CONFIG_LEVEL_BASIC, $LN['pref_default_group'], 'default_group', $LN['pref_default_group_msg'], $default_group_msg, $groups_array, $prefArray['default_group']),
        new pref_select (user_levels::CONFIG_LEVEL_BASIC, $LN['pref_default_feed'], 'default_feed', $LN['pref_default_feed_msg'], $default_feed_msg, $feeds_array, $prefArray['default_feed']),
        new pref_select (user_levels::CONFIG_LEVEL_BASIC, $LN['pref_default_spot'], 'default_spot', $LN['pref_default_spot_msg'], $default_spot_msg, $spot_array, $prefArray['default_spot']),
        );

$downloading = array (
        new pref_select (user_levels::CONFIG_LEVEL_BASIC, $LN['basket_type'],  'basket_type', $LN['basket_type_msg'], $basket_type_msg, $basket_type_array, $prefArray['basket_type']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['add_setname'], 'add_setname',$LN['add_setname_msg'], $add_setname_msg, $prefArray['add_setname']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['mail_user'], 'mail_user',$LN['mail_user_msg'], $mail_user_msg, $prefArray['mail_user'], NULL, NULL,  $sendmail?'':'hidden'),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['mail_user_sets'], 'mail_user_sets',$LN['mail_user_sets_msg'], $mail_user_sets_msg, $prefArray['mail_user_sets'], NULL, NULL, ($sendmail )?'':'hidden'),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['download_par'], 'download_par', $LN['download_par_msg'], $download_par_msg, $prefArray['download_par']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['unpar'], 'unpar', $LN['unpar_msg'], $unpar_msg, $prefArray['unpar']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['unrar'], 'unrar',$LN['unrar_msg'], $unrar_msg, $prefArray['unrar']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['delete_files'], 'delete_files', $LN['delete_files_msg'], $delete_files_msg, $prefArray['delete_files']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['download_text_file'], 'download_text_file', $LN['download_text_file_msg'], $download_text_file_msg, $prefArray['download_text_file']),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['use_auto_download'], 'use_auto_download', $LN['use_auto_download_msg'], $use_auto_download_msg, $prefArray['use_auto_download'],  'toggle_hide(\'autodlnzb\', \'hidden\');', NULL, $auto_download?'':'hidden'),
        new pref_checkbox (user_levels::CONFIG_LEVEL_BASIC, $LN['use_auto_download_nzb'], 'use_auto_download_nzb', $LN['use_auto_download_nzb_msg'], $use_auto_download_nzb_msg, $prefArray['use_auto_download_nzb'], NULL, 'autodlnzb', ($auto_download &&$prefArray['use_auto_download']) ?'':'hidden'),
        new pref_text (user_levels::CONFIG_LEVEL_ADVANCED, $LN['format_dl_dir'], 'format_dl_dir',$LN['format_dl_dir_msg'], $format_dl_dir_msg, $prefArray['format_dl_dir'], TEXT_BOX_SIZE),
        new pref_numeric (user_levels::CONFIG_LEVEL_ADVANCED, $LN['download_delay'], 'download_delay', $LN['download_delay_msg'], $download_delay_msg, $prefArray['download_delay'], NUMBER_BOX_SIZE),
        new pref_select (user_levels::CONFIG_LEVEL_ADVANCED, $LN['config_cancel_crypted_rars'], 'cancel_crypted_rars', $LN['config_cancel_crypted_rars_msg'], $cancel_crypted_rars_msg, $encrar_array, $prefArray['cancel_crypted_rars']),
        new pref_text (user_levels::CONFIG_LEVEL_ADVANCED, $LN['subs_lang'], 'subs_lang',$LN['subs_lang_msg'], $subs_lang_msg, $prefArray['subs_lang'], TEXT_BOX_SIZE),
        );


if (count($category_array) > 0) {
    foreach($spot_categories as $sc) {
        $downloading[] = new pref_select (user_levels::CONFIG_LEVEL_ADVANCED, $LN['spots_category_mapping'] . ' ' . $LN[$sc],  'spot_category_' . $sc, 
                $LN['spots_category_mapping_msg'] , $spot_category_msg[$sc], $category_array, isset($prefArray['spot_category_'. $sc]) ? $prefArray['spot_category_'. $sc] : '');
    }
}

$downloading[] = new pref_select (user_levels::CONFIG_LEVEL_BASIC, $LN['search_type'],  'search_type', $LN['search_type_msg'], $search_type_msg, $search_type_array, $prefArray['search_type']);
$downloading[] = new pref_textarea (user_levels::CONFIG_LEVEL_BASIC, $LN['search_terms'], 'search_terms',$LN['search_terms_msg'], '', utf8_decode($search_terms), 10, 40);
$downloading[] = new pref_textarea (user_levels::CONFIG_LEVEL_BASIC, $LN['blocked_terms'], 'blocked_terms',$LN['blocked_terms_msg'], '', utf8_decode($blocked_terms), 10 , 40);


if ($allow_global_scripts != 0) {
    if (count($global_scripts_array) > 0) {
        $downloading[] = new pref_multiselect (user_levels::CONFIG_LEVEL_ADVANCED, $LN['pref_global_scripts'], 'global_scripts[]', $LN['pref_global_scripts_msg'], $global_scripts_msg, $global_scripts_array, 5);
    }
    if ($allow_user_scripts != 0 && count($user_scripts_array) > 0) {
        $downloading[] = new pref_multiselect (user_levels::CONFIG_LEVEL_ADVANCED, $LN['pref_user_scripts'], 'user_scripts[]', $LN['pref_user_scripts_msg'], $user_scripts_msg, $user_scripts_array, 5);
    }
}


$posting = array (
        new pref_text (user_levels::CONFIG_LEVEL_BASIC, $LN['poster_email'], 'poster_email',$LN['poster_email_msg'], $poster_email_msg, $prefArray['poster_email'], TEXT_BOX_SIZE ),
        new pref_text (user_levels::CONFIG_LEVEL_BASIC, $LN['poster_name'], 'poster_name',$LN['poster_name_msg'], $poster_name_msg, $prefArray['poster_name'], TEXT_BOX_SIZE ),
        new pref_numeric (user_levels::CONFIG_LEVEL_ADVANCED, $LN['recovery_size'], 'recovery_size',$LN['recovery_size_msg'], $recovery_size_msg, $prefArray['recovery_size'], NUMBER_BOX_SIZE ),
        new pref_numeric (user_levels::CONFIG_LEVEL_ADVANCED, $LN['rarfile_size'], 'rarfile_size',$LN['rarfile_size_msg'], $rarfile_size_msg, $prefArray['rarfile_size'], NUMBER_BOX_SIZE ),
        );


$pref_list[] = new pref_list('pref_display',        $display);
if ($module_config[urd_modules::URD_CLASS_DOWNLOAD]) {
    $pref_list[] = new pref_list('pref_downloading',	$downloading);
}
$pref_list[] = new pref_list('pref_login',		    $login);
if ($module_config[urd_modules::URD_CLASS_POST]) {
    $pref_list[] = new pref_list('pref_posting',	    $posting);
}

init_smarty($LN['pref_title'], 1, $add_menu);
$smarty->assign('__message',	$__message);
$smarty->assign('level', 		isset($prefArray['pref_level']) ? $prefArray['pref_level'] : 0);
$smarty->assign('saved', 		$saved);
$smarty->assign('imported', 	$imported);
$smarty->assign('pref_list', 	$pref_list);
$smarty->assign('active_page', 	str_replace(' ', '', get_post('current_tab', 'pref_display')));
$smarty->assign('referrer', 	basename(__FILE__, '.php'));
$smarty->display('settings.tpl');


