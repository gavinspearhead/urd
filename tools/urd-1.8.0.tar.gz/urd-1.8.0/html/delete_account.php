<?php
/*
 *  This file is part of Urd.
*  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2011-06-12 19:26:25 +0200 (zo, 12 jun 2011) $
 * $Rev: 2218 $
 * $Author: gavinspearhead $
 * $Id: delete_account.php 2218 2011-06-12 17:26:25Z gavinspearhead $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);

$pathda = realpath(dirname(__FILE__));

require_once "$pathda/../functions/ajax_includes.php";
require_once "$pathda/../functions/web_functions.php";


if (isset($_POST['delete_account']) && $_POST['delete_account'] == 1) {
    challenge::verify_challenge_text($_POST['challenge']);
    delete_user($db, $userID);
    die_html('OK' . $LN['account_deleted']);
} else {
    die_html('FALSE');
}


