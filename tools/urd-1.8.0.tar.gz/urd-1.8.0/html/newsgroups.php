<?php
/*
 *  This file is part of Urd.
 *  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2013-03-02 23:44:17 +0100 (za, 02 mrt 2013) $
 * $Rev: 2798 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: newsgroups.php 2798 2013-03-02 22:44:17Z gavinspearhead@gmail.com $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);

$pathng = realpath(dirname(__FILE__));


require_once "$pathng/../functions/html_includes.php";
require_once "$pathng/../functions/periods.php";


verify_access($db, urd_modules::URD_CLASS_GROUPS, FALSE, '', $userID, FALSE);
$categories = get_categories($db, $userID);
$cmd = get_request('cmd', 'show');


$add_menu = array (
    'actions'=> 
    array(
        new menu_item2 ('editcategories', 'editcategories', urd_modules::URD_CLASS_GROUPS, '', 'command'),
    )
);


if ($isadmin) {
    $add_menu['actions'][] = new menu_item2('updategroups', 'adminupdatenglist', urd_modules::URD_CLASS_GROUPS, '', 'command');
    $add_menu['actions'][] = new menu_item2('import_groups', 'import_groups', urd_modules::URD_CLASS_GROUPS, '', 'command');
    $add_menu['actions'][] = new menu_item2('export_groups', 'export_groups', urd_modules::URD_CLASS_GROUPS, '', 'command');
} elseif (urd_user_rights::is_updater($db, $userID)) { 
    $add_menu['actions'][] = new menu_item2('updategroups', 'adminupdatenglist', urd_modules::URD_CLASS_GROUPS, '', 'command');
}


$allgroups = array();

try {
	if ($cmd ==  'export') {
		header('Content-Type: text/html/force-download');
        header('Content-Disposition: attachment; filename=urd_group_settings.xml');
        $xml = new urd_xml_writer('php://output');
        $xml->write_newsgroups($db);
        $xml->output_xml_data();
		die;
	} elseif ($cmd == 'import' && isset ($_FILES['filename']['tmp_name']) && $isadmin) {
        challenge::verify_challenge($_POST['challenge']);
        $xml = new urd_xml_reader($_FILES['filename']['tmp_name']);
		$groups = $xml->read_newsgroup_settings($db);
		if ($groups != array()) {
			clear_all_groups($db, $userID);
			set_all_groups($db, $groups, $userID);
		} else {
            $__message[] = $LN['settings_notfound'];
        }
	} elseif ($cmd == 'update') {
		if ($isadmin && $urdd_online) {
            challenge::verify_challenge($_POST['challenge']);
			update_ng_subscriptions ($db, $uc, $userID);
		}	
        challenge::verify_challenge($_POST['challenge']);
        update_user_ng_info($db, $userID);
	}

    $search = utf8_decode(trim(get_request('search', '')));
    $search_all = get_post('search_all', '');
} catch (exception $e) {
	fatal_error($e->getMessage());
}

if (isset($__message)) {
    $smarty->assign('__message',       $__message);
}

list($pkeys, $ptexts) = $periods->get_periods();


init_smarty($LN['ng_title'], 1, $add_menu);
$smarty->assign('search', $search);
$smarty->assign('search_all', $search_all);
	
$smarty->display('newsgroups.tpl');


