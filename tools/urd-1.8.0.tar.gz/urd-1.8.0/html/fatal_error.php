<?php
/*
 *  This file is part of Urd.
 *  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2012-10-15 23:23:47 +0200 (ma, 15 okt 2012) $
 * $Rev: 2711 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: fatal_error.php 2711 2012-10-15 21:23:47Z gavinspearhead@gmail.com $
 */

if (!defined('ORIGINAL_PAGE')) {
    die('This file cannot be accessed directly.');
}

$pathfe = realpath(dirname(__FILE__));
require_once "$pathfe/../functions/smarty.php";


function ajax_fatal_error($msg, $link=NULL, $link_msg=NULL)
{
    global $smarty;
    init_smarty('', 0);
    $msg = html_entity_decode($msg, ENT_QUOTES);
	$smarty->assign('__message', array($msg));
	$smarty->assign('link', $link);
	$smarty->assign('link_msg', $link_msg);
	$smarty->assign('showmenu', 0);
	$smarty->display('fatal_error.tpl');
	die();
}


function fatal_error($msg, $link=NULL, $link_msg=NULL, $closelink='back')
{
    global $smarty, $LN;
    $msg = html_entity_decode($msg, ENT_QUOTES);
    init_smarty($LN['fatal_error_title'], 1);
	$smarty->assign('__message', array($msg));
	$smarty->assign('link', $link);
    $smarty->assign('link_msg', $link_msg);
	$smarty->assign('closelink', $closelink);

	$smarty->display('fatal_error.tpl');
	die();
}


function near_fatal_error($msg, $ignore_name, $ignore_value=NULL, $link=NULL, $link_msg=NULL)
{ //used in browse for disk full check and timestamp check. In case the continue button is pressed, the $ignore_name has its value overwritten in the form and is then reposted
	global $smarty, $LN;
	$action = $_SERVER['REQUEST_URI']; // get the form name
	$cnt = 0;
    $post= array();
    foreach ($_POST as $name => $value){
		if ($name == $ignore_name) { 
			$cnt++;
			if ($ignore_value !== NULL) { // replace the value with a new one; if null remove it
                $post[] = array('name' => $ignore_name, 'value' => $ignore_value);
            }
        } else {
            // other variables are copied
            $post[] = array('name' => $name, 'value' => $value);
        }
	}
	if ($cnt == 0) {// add it if it isn't part of the post yet
        $post[] = array('name' => $ignore_name, 'value' => $ignore_value);
    }

    $msg = html_entity_decode($msg, ENT_QUOTES);
    init_smarty($LN['fatal_error_title'], 1);
	$smarty->assign('__message', array($msg));
	$smarty->assign('action', $action);
	$smarty->assign('link', $link);
	$smarty->assign('post', $post);
	$smarty->assign('link_msg', $link_msg);

	$smarty->display('fatal_error.tpl');
	die();
}


function semi_fatal_error($msg, $link=NULL, $link_msg=NULL)
{ // function is used for challenges that are too old; resets the challenge to a new value + resets the timeout
	global $smarty, $LN;
    $action = $_SERVER['REQUEST_URI']; // get the form name
    $post= array();
	foreach ($_POST as $name=>$value){
		if ($name == 'challenge') {
			$post[] = array('name' => 'challenge', 'value' => challenge::set_challenge());
        } else {
            $post[] = array('name' => $name, 'value' => $value);
        }
	}

    $msg = html_entity_decode($msg, ENT_QUOTES);
    init_smarty($LN['fatal_error_title'], 1);
	$smarty->assign('__message', array($msg));
	$smarty->assign('action', $action);
	$smarty->assign('link', $link);
	$smarty->assign('post', $post);
	$smarty->assign('link_msg', $link_msg);
	$smarty->display('fatal_error.tpl');
	die();
}


