<?php
/*
 *  This file is part of Urd.
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2013-03-02 23:44:17 +0100 (za, 02 mrt 2013) $
 * $Rev: 2798 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: action.php 2798 2013-03-02 22:44:17Z gavinspearhead@gmail.com $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);

$pathac = realpath(dirname(__FILE__));
require_once "$pathac/../functions/ajax_includes.php";
require_once "$pathac/../functions/buttons.php";

$prefs = load_config($db);
$uc = new urdd_client($db, $prefs['urdd_host'], $prefs['urdd_port'], $userID);

function check_connected($uc)
{
    global $LN;
    if ($uc->is_connected() === FALSE) {
        die_html($LN['error_urddconnect']);
    }
}

if (isset($_GET['cmd']) && $_GET['cmd'] == 'export_all') {
    // we will accept export also from a GET request
    $command = 'export_all';
} elseif (!isset($_POST['cmd'])) {
    die_html($LN['error_novalidaction']);
} else {
    // everything else is a post
    $command = strtolower(get_post('cmd'));
    challenge::verify_challenge_text($_POST['challenge']);
}


function update_spots(DatabaseConnection $db, urdd_client $uc,  $userID)
{
    try {
        verify_access($db, NULL, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $uc->update('', USERSETTYPE_SPOT);
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function expire_spots(DatabaseConnection $db, urdd_client $uc,  $userID)
{
    try {
        verify_access($db, NULL, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $uc->expire('', USERSETTYPE_SPOT);
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function purge_spots(DatabaseConnection $db, urdd_client $uc,  $userID)
{
    try {
        verify_access($db, NULL, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $uc->purge('', USERSETTYPE_SPOT);
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function find_servers(DatabaseConnection $db, urdd_client $uc, $userID, $extended=FALSE)
{
    try {
        verify_access($db, NULL, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $ext_str = '';
        if ($extended) {
            $ext_str = 'extended';
        }
        $uc->findservers($ext_str);
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function clean_db(DatabaseConnection $db, urdd_client $uc, $userID, $all=FALSE)
{
    try {
        verify_access($db, NULL, FALSE, '', $userID, TRUE);
        check_connected($uc);
        $all_str = 'now';
        if ($all) {
            $all_str = 'all';
        };
        $uc->cleandb();
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
    break;
}


function update_blacklist(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_SPOTS, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $uc->update_blacklist();
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function update_whitelist(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_SPOTS, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $uc->update_whitelist();
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function update_articles(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $uc->update('all', USERSETTYPE_GROUP);
        $uc->disconnect();
        add_stat_data($db, stat_actions::UPDATE, 'all', $userID);
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function update_newsgroups(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, 'M',  $userID, TRUE);
        check_connected($uc);
        $uc->update_newsgroups();
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function gensets_articles(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $uc->gensets('all');
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function purge_articles(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $uc->purge('all', USERSETTYPE_GROUP);
        $uc->disconnect();
        add_stat_data($db, stat_actions::PURGE, 'all', $userID);
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }

}


function expire_articles(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $uc->expire('all', USERSETTYPE_GROUP);
        $uc->disconnect();
        add_stat_data($db, stat_actions::EXPIRE, 'all', $userID);
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function gensets_group(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $id = get_request('group');
        if (substr($id, 0, 9) == 'category_') {
            $id = substr($id, 9);
            $ids = get_groups_by_category($db, $userID, $id);
            foreach($ids as $i) {
                if (is_numeric($i)) {
                    $uc->gensets($i);
                }
            }
        } else {
            if (substr($id, 0, 6) == 'group_') {
                $id = substr($id, 6);
            } 
            if (is_numeric($id)) {
                $uc->gensets($id);
            }
        }

        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function update_newsgroup(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $id = get_request('group');
        if (substr($id, 0, 9) == 'category_') {
            $id = substr($id, 9);
            $ids = get_groups_by_category($db, $userID, $id);
            foreach($ids as $i) {
                if (is_numeric($i)) {
                    $uc->update($i, USERSETTYPE_GROUP);
                    add_stat_data($db, stat_actions::UPDATE, $i, $userID);
                }
            }
        } else {
            if (substr($id, 0, 6) == 'group_') {
                $id = substr($id, 6);
            } 
            if (is_numeric($id)) {
                $uc->update($id, USERSETTYPE_GROUP);
                add_stat_data($db, stat_actions::UPDATE, $id, $userID);
            }
        }

        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function optimise(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, NULL, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $uc->optimise();
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function check_version(urdd_client $uc)
{
    try {
        check_connected($uc);
        $uc->check_version();
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function update_rss(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_RSS, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $id = get_request('group');
        if (substr($id, 0, 9) == 'category_') {
            $id = substr($id, 9);
            $ids = get_groups_by_category($db, $userID, $id);
            foreach($ids as $i) {
                if (is_numeric($i)) {
                    $uc->update($i, USERSETTYPE_RSS);
                    add_stat_data($db, stat_actions::UPDATE, $i, $userID);
                }
            }
        } else {
            if (substr($id, 0, 5) == 'feed_') {
                $id = substr($id, 5);
            } 
            if (is_numeric($id)) {
                $uc->update($id, USERSETTYPE_RSS);
                add_stat_data($db, stat_actions::UPDATE, $id, $userID);
            }
        } 
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function update_rss_all(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_RSS, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $uc->update('all', USERSETTYPE_RSS);
        $uc->disconnect();
        add_stat_data($db, stat_actions::UPDATE, 'all', $userID);
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function expire_newsgroups(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $id = get_request('group');
        $db->escape($id);
        if (substr($id, 0, 9) == 'category_') {
            $id = substr($id, 9);
            $ids = get_groups_by_category($db, $userID, $id);
            foreach($ids as $i) {
                if (is_numeric($i)) {
                    $uc->expire($i, USERSETTYPE_GROUP);
                }
            }
        } else {
            if (substr($id, 0, 6) == 'group_') {
                $id = substr($id, 6);
            } 
            if (is_numeric($id)) {
                $uc->expire($id, USERSETTYPE_GROUP);
            }
        }

        $uc->disconnect();
        add_stat_data($db, stat_actions::EXPIRE, $id, $userID);
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function purge_rss_all(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_RSS, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $uc->purge('all', USERSETTYPE_RSS);
        $uc->disconnect();
        add_stat_data($db, stat_actions::PURGE, 'all', $userID);
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function expire_rss_all(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_RSS, TRUE, 'M', $userID, TRUE);
        check_connected($uc);
        $uc->expire('all', USERSETTYPE_RSS);
        $uc->disconnect();
        add_stat_data($db, stat_actions::EXPIRE, 'all', $userID);
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function expire_rss(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_RSS, TRUE, '', $userID);
        check_connected($uc);
        $id = get_request('group');
        if (substr($id, 0, 9) == 'category_') {
            $id = substr($id, 9);

            $ids = get_feeds_by_category($db, $userID, $id);
            foreach($ids as $i) {
                if (is_numeric($i)) {
                    $uc->expire($i, USERSETTYPE_RSS);
                    add_stat_data($db, stat_actions::EXPIRE, $i, $userID);
                }
            }
        } else {
            if (substr($id, 0, 5) == 'feed_') {
                $id = substr($id, 5);
            } 
            if (is_numeric($id)) {
                $uc->expire($id, USERSETTYPE_RSS);
                add_stat_data($db, stat_actions::EXPIRE, $id, $userID);
            }
        }

        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function purge_rss(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_RSS, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $id = get_request('group');
        $db->escape($id);
        if (substr($id, 0, 9) == 'category_') {
            $id = substr($id, 9);
            $ids = get_feeds_by_category($db, $userID, $id);
            foreach($ids as $i) {
                if (is_numeric($i)) {
                    $uc->purge($i, USERSETTYPE_RSS);
                    add_stat_data($db, stat_actions::PURGE, $i, $userID);
                }
            }
        } else {
            if (substr($id, 0, 5) == 'feed_') {
                $id = substr($id, 5);
            } 
            if (is_numeric($id)) {
                $uc->purge($id, USERSETTYPE_RSS);
                add_stat_data($db, stat_actions::PURGE, $id, $userID);
            }
        }

        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function clean_all(urdd_client $uc)
{
    // Clear completed downloads:
    if ($uc->is_connected()) {
        $uc->cleandb('now');
        die_html('OK');
    } else {
        die_html($LN['error_urddconnect']);
    }
}


function purge_newsgroups(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $id = get_request('group');
        $db->escape($id);
        if (substr($id, 0, 9) == 'category_') {
            $id = substr($id, 9);
            $ids = get_groups_by_category($db, $userID, $id);
            foreach($ids as $i) {
                if (is_numeric($i)) {
                    $uc->purge($i, USERSETTYPE_GROUP);
                }
            }
        } else {
            if (substr($id, 0, 6) == 'group_') {
                $id = substr($id, 6);
            } 
            if (is_numeric($id)) {
                $uc->purge($id, USERSETTYPE_GROUP);
            }
        }
        $uc->disconnect();
        add_stat_data($db, stat_actions::PURGE, $id, $userID);
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function get_setinfo(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_SYNC, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $uc->getsetinfo();
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function send_setinfo(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, urd_modules::URD_CLASS_SYNC, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $uc->sendsetinfo();
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function clean_dir(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        verify_access($db, NULL, TRUE, '', $userID, TRUE);
        check_connected($uc);
        $uc->cleandir('all');
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function unschedule_job(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        $job = get_post('job');
        $uc->unschedule($job, '');
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function delete_task(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        $task = get_post('task');
        if (!is_numeric($task)) {
            die_html($LN['error_notanumber']);
        }
        $db->escape($task, TRUE);

      //  $sql = "DELETE FROM queueinfo WHERE \"ID\" = $task";
        $db->delete_query('queueinfo', "\"ID\" = $task");
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function cancel_all_tasks(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        check_connected($uc);
        $uc->cancel('all');
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function cancel_task(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        $task = get_post('task');
        $uc->cancel($task);
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function pause_task(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        $task = get_post('task');
        $uc->pause($task);
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function continue_task(DatabaseConnection $db, urdd_client $uc, $userID)
{
    try {
        $task = get_post('task');
        $uc->continue_cmd($task);
        $uc->disconnect();
        die_html('OK');
    } catch(exception$e) {
        die_html($e->GetMessage());
    }
}


function import_all(DatabaseConnection $db, urdd_client $uc,  $userID)
{
    verify_access($db, NULL, TRUE, '', $userID, TRUE);
    check_connected($uc);
    if (isset($_FILES['filename']['tmp_name'])) {
        try {
            $xml = new urd_xml_reader($_FILES['filename']['tmp_name']);
            $settings = $xml->read_all_settings($db);
            clear_all_feeds($db, $userID);
            clear_all_groups($db, $userID);
            clear_all_usenet_servers($db);
            clear_all_buttons($db);
            stop_urdd($userID);
            clear_all_users($db);
            clean_config($db);

            reset_config($db);
            set_configs($db, $settings['config']);
            set_all_users($db, $settings['users'], $settings['users_settings']);
            set_all_buttons($db, $settings['buttons']);
            set_all_usenet_servers($db, $settings['usenet_servers']);
            $userID = get_admin_userid($db);
            // we need to get the ID of the first admin we find since we reloaded users
            start_urdd();
            $s_time = time();
            $uprefs = load_config($db);
            while (1) {
                try {
                    $uc = new urdd_client($db, $uprefs['urdd_host'], $uprefs['urdd_port'], $userID);
                }
                catch(execption$e) {
                }
                if ($uc->is_connected()) {
                    break;
                } else {
                    sleep(1);
                    // sleep one second before we try again
                    if (time() - $s_time >= 60) {
                        // until 1 minute has passed... probably an incompatible config loaded
                        throw new exception('urdd has not started yet... stopping');
                    }
                }
            }
            set_all_groups($db, $settings['newsgroups'], $userID);
            set_all_feeds($db, $settings['rssfeeds'], $userID);
        }
        catch(exception $e) {
            die_html("Error occurerd {$e->getMessage()}");
        }
        redirect('index.php');
    }
    die;
}


function add_search(DatabaseConnection $db, $userID)
{
    global $LN;
    $type = trim(get_post('type', ''));
    $value = trim(get_post('value', ''));
    if ($type == 'search') {
        if ($value  != '') {
            add_line_to_text_area($db, 'search_terms', $value, $userID);
        }
    } elseif ($type == 'block') {
        if ($value  != '') {
            add_line_to_text_area($db, 'blocked_terms', $value, $userID);
        }
    } else {
        die_html($LN['error_unknowntype']);
    }
    die_html('OK');
}


function add_blacklist(DatabaseConnection $db)
{
    global $LN;
    challenge::verify_challenge_text($_POST['challenge']);
    $spotid = trim(get_post('spotid', ''));
    $spotterid = get_spotterid_from_spot($db, $spotid);
    if ($spotterid !== FALSE) {
        add_to_blacklist($db, $spotterid);
        die_html('OK');
    } else {
        die_html($LN['error_spotnotfound']);
    }
}


switch ($command) {
    case 'unschedule':
        unschedule_job($db, $uc, $userID);
        break;
    case 'delete_task':
        delete_task($db, $uc, $userID);
        break;
    case 'cancel':
        cancel_task($db, $uc, $userID);
        break;
    case 'pause':
        pause_task($db, $uc, $userID);
        break;
    case 'continue':
        continue_task($db, $uc, $userID);
        break;
    case 'export_all':
        verify_access($db, NULL, TRUE, '', $userID, TRUE);
        export_settings($db, 'all', 'urd_all_settings.xml');
        break;
    case 'import_all':
        import_all($db, $uc, $userID);
    case 'add_search':
        add_search($db, $userID);
        break;
    case 'add_blacklist':
        add_blacklist($db);
        break;
    case 'updatespots':
        update_spots($db, $uc, $userID);
        break;
    case 'expirespots':
        expire_spots($db, $uc, $userID);
        break;
    case 'purgespots':
        purge_spots($db, $uc, $userID);
        break;
    case 'findservers':
        find_servers($db, $uc, $userID);
        break;
    case 'findservers_ext':
        find_servers($db, $uc, $userID, TRUE);
        break;
    case 'cleandb_all':
        clean_db($db, $uc, $userID, TRUE);
        break;
    case 'cleandb':
        clean_db($db, $uc, $userID, FALSE);
        break;
    case 'updatearticles':
        update_articles( $db, $uc, $userID);
        break;
    case 'updatewhitelist':
        update_whitelist( $db, $uc, $userID);
        break;
    case 'updateblacklist':
        update_blacklist( $db, $uc, $userID);
    case 'updategroups':
        update_newsgroups( $db, $uc, $userID);
        break;
    case 'gensetsarticles':
        gensets_articles($db, $uc, $userID);
        break;
    case 'purgearticles':
        purge_articles($db, $uc, $userID);
        break;
    case 'expirearticles':
        expire_articles($db, $uc, $userID);
        break;
    case 'gensetsgroup':
        gensets_group($db, $uc, $userID);
        break;
    case 'updategroup':
        update_newsgroup($db, $uc, $userID);
        break;
    case 'optimise':
        optimise($db, $uc, $userID);
        break;
    case 'checkversion':
        check_version($uc);
        break;
    case 'updaterssall':
        update_rss_all($db, $uc, $userID);
        break;
    case 'updaterss':
        update_rss($db, $uc, $userID);
        break;
    case 'expiregroup':
        expire_newsgroups( $db, $uc, $userID);
        break;
    case 'expirerssall':
        expire_rss_all($db, $uc, $userID);
        break;
    case 'purgerssall':
        purge_rss_all($db, $uc, $userID);
        break;
    case 'expirerss':
        expire_rss($db, $uc, $userID);
        break;
    case 'purgerss':
        purge_rss($db, $uc, $userID);
        break;
    case 'cancelall' : 
        cancel_all_tasks($db, $uc, $userID);
        break;
    case 'cleanall' : 
        clean_all($uc);
        break;
    case 'purgegroup':
        purge_newsgroups($db, $uc, $userID);
        break;
    case 'getsetinfo':
        get_setinfo($db, $uc, $userID);
        break;
    case 'sendsetinfo':
        send_setinfo($db, $uc, $userID);
        break;
    case 'cleandir':
        clean_dir($db, $uc, $userID);
        break;
    case 'poweron' : 
		// Turn URDD on
        verify_access($db, NULL, TRUE, '', $userID, TRUE);
		start_urdd(); 
		break;
	case 'poweroff' : 
		// Turn URDD off
        verify_access($db, NULL, TRUE, '', $userID, TRUE);
		stop_urdd($userID);
		break;
    default:
        die_html($LN['error_novalidaction']);
        break;
}

