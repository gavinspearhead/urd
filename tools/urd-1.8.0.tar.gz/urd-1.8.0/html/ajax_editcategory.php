<?php
/*
 *  This file is part of Urd.
 *  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not 
 *  exist, see <http://www.gnu.org/licenses/>.
 * 
 * $LastChangedDate: 2013-03-02 23:44:17 +0100 (za, 02 mrt 2013) $
 * $Rev: 2798 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: ajax_editcategory.php 2798 2013-03-02 22:44:17Z gavinspearhead@gmail.com $
 */


define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);

$__auth = 'silent';

$pathaec = realpath(dirname(__FILE__));

require_once "$pathaec/../functions/ajax_includes.php";
require_once "$pathaec/../functions/mail_functions.php";


$cmd = get_request('cmd', '');



switch($cmd) {
case 'delete_category':
    challenge::verify_challenge_text($_POST['challenge']);
    $id = get_request('id');
    if (is_numeric($id) && $id > 0) {
        delete_category($db, $id, $userID);
    } else {
        die_html('No ID found');
    }
    break;
case 'update_category':
    challenge::verify_challenge_text($_POST['challenge']);
    $id = get_request('id');
    $name = get_request('name', '');
    if ($name == '') {
        die_html('No name found');
    }
    if ($id == 'new' || $id == 0) {
        insert_category($db, $userID, $name);
    } elseif (is_numeric($id)) {
        update_category($db, $id, $userID, $name);
    } else {
        die_html('No ID found');
    }
    break;
case 'get_name':
    $id = get_request('id');
    if (!is_numeric($id)) {
        die_html('No ID found');
    }
    $name = get_category($db, $id, $userID);
    if ($name == '') {
        die_html ('__error__');
    } else {
        die_html($name);
    }
    break;

case 'edit':
    $categories = get_categories($db, $userID); 
    foreach($categories as &$cat) {
        $cat['name'] = $cat['name'];
    }
    init_smarty('', 0);
    $smarty->assign('categories',	    $categories);
    $smarty->assign('text_box_size',		TEXT_BOX_SIZE);
    $smarty->display('ajax_editcategories.tpl');
    die;
default:
    die_html ("O-oh - Unknown command $cmd");
    break;
}

die_html('OK');

