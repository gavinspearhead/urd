<?php
/*
 *  This file is part of Urd.
 *  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2012-05-13 19:08:30 +0200 (zo, 13 mei 2012) $
 * $Rev: 2514 $
 * $Author: gavinspearhead $
 * $Id: transfers.php 2514 2012-05-13 17:08:30Z gavinspearhead $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);

$pathtr = realpath(dirname(__FILE__));

require_once "$pathtr/../functions/html_includes.php" ;

verify_access($db, urd_modules::URD_CLASS_DOWNLOAD | urd_modules::URD_CLASS_POST | urd_modules::URD_CLASS_USENZB, FALSE, '', $userID, FALSE);


$add_menu = array (
    'actions'=> 
    array(
        new menu_item2('getnzb', 'transfers_importnzb',urd_modules::URD_CLASS_GENERIC, '', 'command'),
        new menu_item2('post','transfers_post',urd_modules::URD_CLASS_POST, '', 'command'),
        new menu_item2('continueall','transfers_continueall',urd_modules::URD_CLASS_GENERIC, '', 'command'),
        new menu_item2('pauseall', 'transfers_pauseall',urd_modules::URD_CLASS_GENERIC, '', 'command'),
        new menu_item2('cleandb','transfers_clearcompleted',urd_modules::URD_CLASS_GENERIC, '', 'command'),
    )
);


$poster = urd_user_rights::is_poster($db, $userID);
init_smarty($LN['transfers_title'], 1, $add_menu);

$active_tab = get_request('active_tab', '');

if ($active_tab == '') {
    $active_tab = get_session('transfers', 'downloads');
}

$smarty->assign('poster',         	    $poster ? 1 : 0);
$smarty->assign('active_tab',           $active_tab);
$smarty->assign('offline_message',      $LN['enableurddfirst']);
$smarty->display('transfers.tpl');


