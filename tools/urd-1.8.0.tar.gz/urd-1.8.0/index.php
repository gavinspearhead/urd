<?php

/*
 *  This file is part of Urd.
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2012-07-22 00:30:12 +0200 (zo, 22 jul 2012) $
 * $Rev: 2603 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: index.php 2603 2012-07-21 22:30:12Z gavinspearhead@gmail.com $
 */


// If not installed, go to install.php, otherwise go to the normal index page:
if (!file_exists('.installed')) {
	header('Location: install/install.php');
} else {
	header('Location: html/index.php');
}


