/*
 *  This file is part of Urd.
 *  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2012-09-09 00:59:41 +0200 (zo, 09 sep 2012) $
 * $Rev: 2660 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: js.js 2660 2012-09-08 22:59:41Z gavinspearhead@gmail.com $
 */
"use strict";

function LoadPage(pagenumber)
{
	var installform = document.forms[0];
	var pagenr = document.getElementById('page');
	pagenr.value = pagenumber;
	installform.submit();
}


function toggle_show_password(id)
{
	var pass = document.getElementById(id);
    if (pass.type == "password") { 
        pass.type = "text"; 
    } else { 
        pass.type = "password";
    } 
}


function update_database_input_fields()
{
    var dbt = document.getElementById('dbtype');
    var type = dbt.options[dbt.selectedIndex].value; 
    type = type.toLowerCase();
    change_display_dbengine(type);
    if (type=='pdo_sqlite') {
        hide_data_for_sqlite();
    } else {
        show_data_for_sqlite();
    }

}

function change_display_dbengine(type)
{
    if (type == 'mysql' || type == 'mysqli') {
        $('#dbengine').show();
    } else {
        $('#dbengine').hide();
    }
}



function show_data_for_sqlite()
{
    $("#hostname").show();
    $("#port").show();
    $("#dbusername").show();
    $("#dbpassword").show();
    $("#dbroot").show();
    $("#dbrootpw").show();
    $("#dbmysqlreset").show();
}


function hide_data_for_sqlite()
{
    $("#dbhost").val('');
    $("#dbname").val('');
    $("#dbport").val('');
    $("#dbuser").val('');
    $("#dbpass").val('');
    $("#dbruser").val('');
    $("#dbrpass").val('');
    $("#hostname").hide();
    $("#port").hide();
    $("#dbusername").hide();
    $("#dbpassword").hide();
    $("#dbroot").hide();
    $("#dbrootpw").hide();
    $("#dbmysqlreset").hide();
}


function hide_button(id)
{
    var div = document.getElementById(id);
    div.style.display = "none";
}


function show_message(msg)
{
    var div = document.getElementById('message');
    div.style.display = "block";
    div.innerHTML = msg;
}



function GeneratePassword(length) 
{
    var sPassword = "", i;

    for (i=0; i < length; i++) {
        var numI = getRandomNum();
        while (checkPunc(numI)) { numI = getRandomNum(); } 
        sPassword = sPassword + String.fromCharCode(numI);
    }
    return sPassword;
}

function getRandomNum() {
        
    // between 0 - 1
    var rndNum = Math.random()

    // rndNum from 0 - 1000    
    rndNum = parseInt(rndNum * 1000);

    // rndNum from 33 - 127        
    rndNum = (rndNum % 94) + 33;
            
    return rndNum;
}

function checkPunc(num) {
    
    if ((num >=33) && (num <=47)) { return true; }
    if ((num >=58) && (num <=64)) { return true; }    
    if ((num >=91) && (num <=96)) { return true; }
    if ((num >=123) && (num <=126)) { return true; }
    
    return false;
}

function set_random_password(dbpass)
{
    var val = document.getElementById(dbpass);
    val.value = GeneratePassword(12);
}


function get_value_from_id(id, def)
{
    var val = document.getElementById(id);
    if (val === null) {
        if (def === null) {
            return null;
        } else {
            return def;
        }
    } else {
        return val.value;
    }
}

function fill_in_usenet_form()
{
    var server_id = document.getElementById('server_id');
    server_id = server_id.options[server_id.selectedIndex].value;
    var server_data = get_value_from_id('server_'+server_id, '');
    if (server_data != '') {
        var arr = server_data.split('|')
            var name = arr[0];
        var host = arr[1];
        var port = arr[2];
        var sport = arr[3];
        var conn = arr[4];
        var host_id = document.getElementById('hostname');
        var port_id = document.getElementById('port');
        var conn_id = document.getElementById('connection');
        var serverid = document.getElementById('serverid');
        host_id.value = host;
        serverid = server_id;
        if (conn == "off") {
            port_id.value = port;
        } else {
            port_id.value = sport;
        }    
        for (var i=0; i<conn_id.length; i++) {
            if (conn_id.options[i].value.toLowerCase() == conn.toLowerCase()) {
                conn_id.selectedIndex = i;
                continue;
            }
        }
    }
}


