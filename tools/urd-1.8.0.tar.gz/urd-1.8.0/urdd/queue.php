<?php
/*
 *  This file is part of Urd.
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2012-05-13 19:08:30 +0200 (zo, 13 mei 2012) $
 * $Rev: 2514 $
 * $Author: gavinspearhead $
 * $Id: queue.php 2514 2012-05-13 17:08:30Z gavinspearhead $
 */


// This is an include-only file:
if (!defined('ORIGINAL_PAGE')) {
    die('This file cannot be accessed directly.');
}

$pathq = realpath(dirname(__FILE__));
require_once "$pathq/../functions/autoincludes.php";


function update_download_position(DatabaseConnection $db, action $item, $position)
{
    $command = $item->get_command_code();
    if ($command == urdd_protocol::COMMAND_DOWNLOAD || $command == urdd_protocol::COMMAND_DOWNLOAD_ACTION) {
        $id = $item->get_args();
        $sql = "UPDATE downloadinfo SET \"position\" = '$position' WHERE \"ID\"='$id'";
        $db->execute_query($sql);
    }
}


class queue {
    private $qq;
    private $max_size;
    const MAX_REQUEUE_COUNT = 10000; // the maximum number of times an item can be requeued
    const MOVE_UP = 1;
    const MOVE_DOWN = -1;

    function __construct($max_size=0)
    {
        assert(is_numeric($max_size));
        $this->qq = array();
        $this->max_size = (int)$max_size;
    }
    function __destruct() 
    {
/* empty still */ 
    }
    function size() 
    {
        return count($this->qq); 
    }
    function is_empty() 
    {
        return count($this->qq) == 0; 
    }
    function get_queue() {
        $qq = array();
        foreach($this->qq as $q) {
            $row['id'] = $q->get_id();
            $row['username'] = $q->get_username();
            $row['priority'] = $q->get_priority();
            $row['command'] = $q->get_command();
            $row['args'] = $q->get_args();
            $row['queue_time'] = $q->get_queue_time();
            $row['pause'] = $q->is_paused();

            $qq[] = $row;
        }
        return $qq;
    }
    
        
    function update_all_download_position(DatabaseConnection $db)
    {
        $sql = 'UPDATE downloadinfo SET "position" = \'0\'';
        $db->execute_query($sql);
        $cnt = 0;

        foreach($this->qq as $q) {
            $cnt++;
            update_download_position($db, $q, $cnt);
        }
    }


    function move_down(DatabaseConnection $db, $cmd, $arg, $username)
    {
        $prev = NULL;
        $next = NULL;
        // first find the previous one
        foreach($this->qq as $k=>&$q) {
            if ($prev !== NULL && $prev->is_equal($cmd, $arg) && !$q->is_equal($cmd, $arg)) {
                if ($q->match_username($username)) {
                    $next = $q;
                    break;
                }
            } 
            if ($q->match_username($username)) {
                $prev = $q;
            }
        }
        
        if ($next === NULL) { 
            return FALSE;
        }
        $before = $after = array();
        $previous = $current = array();
        // split the queue
        $found = FALSE;
        foreach($this->qq as $k=>&$q) {
            if ($q->is_equal($cmd, $arg)) {
                $current[$k] = $q;
            } elseif ($q->is_equal($next->get_command(), $next->get_args())) {
                $previous[$k] = $q;
                $found = TRUE;
            } elseif ($found == TRUE) {
                $after[$k] = $q;
            } else {
                $before[$k] = $q;
            }
        }
        
        // swap the priorities
        $prio2 = $prev->get_priority();
        $prio1 = $next->get_priority();
        foreach($current as &$q) {
            $q->set_priority($prio2, $username); 
            update_queue_priority($db, $q->get_dbid(), $prio2);
        }

        foreach($previous as &$q) {
            $q->set_priority($prio1, $username);
            update_queue_priority($db, $q->get_dbid(), $prio1);
        }
        
        $this->qq = array_merge($before, $previous, $current, $after);
        return TRUE;
    }


    function move_up(DatabaseConnection $db, $cmd, $arg, $username)
    {
        $prev = $curr = NULL;
        // first find the previous one
        foreach($this->qq as $k=>&$q) {
            if ($q->is_equal($cmd, $arg) && $q->match_username($username)) {
                if ($prev === NULL) {
                    return FALSE; // it's already at the top
                } else {
                    $curr = $q;
                }
                break;
            } else {
                if ($q->match_username($username)) {
                    $prev = $q;
                }
            }
        }
        if ($prev === NULL || $curr === NULL) {
            return FALSE;
        }
        $before = $after = array();
        $previous = $current = array();
        // split the queue
        $found = FALSE;
        foreach($this->qq as $k=>&$q) {
            if ($q->is_equal($cmd, $arg)) {
                $current[$k] = $q;
            } elseif ($q->is_equal($prev->get_command(), $prev->get_args())) {
                $previous[$k] = $q;
                $found = TRUE;
            } elseif ($found == TRUE) {
                $after[$k] = $q;
            } else {
                $before[$k] = $q;
            }
        }

        // swap the priorities
        $prio1 = $curr->get_priority();
        $prio2 = $prev->get_priority();
        foreach($current as &$q) {
            $q->set_priority($prio2, $username); 
            update_queue_priority($db, $q->get_dbid(), $prio2);
        }

        foreach($previous as &$q) {
            $q->set_priority($prio1, $username);
            update_queue_priority($db, $q->get_dbid(), $prio1);
        }
        
        $this->qq = array_merge($before, $current, $previous, $after);
        return TRUE;
    }

    function move(DatabaseConnection $db, $cmd, $arg, $username, $direction)
    {
        if ($direction == self::MOVE_DOWN) {
            $rv = $this->move_down($db, $cmd, $arg, $username);
        } elseif ($direction == self::MOVE_UP) {
            $rv = $this->move_up($db, $cmd, $arg, $username);
        }
        $this->update_all_download_position($db);
    }   
        
    function push(action $item, DatabaseConnection $db, $increase_counter=TRUE, $priority=NULL) 
    { 
        assert(is_bool($increase_counter));
        if ($priority != NULL) {
            assert(is_numeric($priority));
            $item->set_priority($priority, $item->get_username());
            update_queue_priority($db, $item->get_dbid(), $priority);
        }
        return $this->add_prio($item, $db, $increase_counter); 
    }
    function push_top(action $item, DatabaseConnection $db, $increase_counter=TRUE) 
    { 
        assert(is_bool($increase_counter));
        $item->set_priority(1, $item->get_username());
        return $this->add_prio($item, $db, $increase_counter);
    }
    function move_top(DatabaseConnection$db, $index, $username)
    {
        assert(is_numeric($index));
        foreach($this->qq as $k => $q) {
            if ($q->get_id() == $index) {
                if ($q->match_username($username)) {
                    unset($this->qq[$k]);
                    array_unshift($this->qq, $q);
                    $this->update_all_download_position($db);
                    return;
                } else {
                    throw new exception('Not allowed', ERR_ACCESS_DENIED);
                }
            }
        }
        throw new exception ('Item not found', ERR_ITEM_NOT_FOUND);
    }
    function has_equal(action $a)
    {
        foreach ($this->qq as $q) {
            if ($q->is_equal($a->get_command_code(), $a->get_args())) {
                return TRUE;
            }
        }
        return FALSE;

    }
    function get_ids_all($username)
    {
        $keys = array();
        foreach ($this->qq as $k => $q) {
            if ($q->match_username($username)) {
                $keys[] = $k;
            }
        }
        return $keys;

    }
    function get_ids_cmd($cmd, $arg, $username)
    {
        $keys = array();
        foreach ($this->qq as $k => $q) {
            if ($q->is_equal($cmd, $arg) && $q->match_username($username)) {
                $keys[] = $k;
            }
        }
        return $keys;
    }
    function get_ids_action($action_id, $username)
    {
        assert (is_numeric($action_id));
        $keys = array();
        foreach ($this->qq as $k => $q) {
            if ($action_id == $q->get_id()){
                $keys[] = $k;
            }
        }
        return $keys;
    }
    function delete_ids(DatabaseConnection $db, array $ids, $username, $delete_db=FALSE)
    {
        assert(is_bool($delete_db));
        $cnt = 0;
        foreach($ids as $id) {
            if (isset($this->qq[$id])) {
                if ($this->qq[$id]->match_username($username)) {
                    if ($delete_db) {
                        $status = QUEUE_CANCELLED;
                        update_queue_status($db, $this->qq[$id]->get_dbid(), $status);
                    }
                    unset($this->qq[$id]);
                    $cnt ++;
                } else {
                    throw new exception ('Not allowed', ERR_ACCESS_DENIED);
                }
            } else {
                throw new exception ('Queue item not found', ERR_ITEM_NOT_FOUND);
            }
        }
        return $cnt;
    }
    function get_queue_item($id)
    {
        assert(is_numeric($id));
        if (isset($this->qq[$id])) {
            return $this->qq[$id];
        } else {
            throw new exception ('Queue item not found', ERR_ITEM_NOT_FOUND);
        }
    }


    function delete_cmd(DatabaseConnection $db, $cmd, $arg, $username, $delete_db = FALSE)
    {
        assert(is_bool($delete_db));
        $kk = array();
        foreach ($this->qq as $k => $q) {
            if ($q->is_equal($cmd, $arg)) {
                $kk[] = $k;
            }
        }
        if (empty($kk)) {
            return FALSE;
        }

        foreach ($kk as $k) {
            if (!$this->qq[$k]->match_username($username)) {
                throw new exception ('Not allowed', ERR_ACCESS_DENIED);
            }
            $item = $this->qq[$k];
            unset($this->qq[$k]);
            if($delete_db === TRUE) {
                $status = QUEUE_CANCELLED;
                update_queue_status($db, $item->get_dbid(), $status);
            }
        }
        $this->update_all_download_position($db);
        return TRUE;
    }


    function get_preview_action()
    {
        foreach ($this->qq as $q) {
            if ($q->get_preview() && !$q->is_paused()) {
                return $q;
            }
        }
        return FALSE;
    }

        
    function delete(DatabaseConnection $db, $action_id, $username, $delete_db = FALSE)
    {
        assert(is_bool($delete_db) && is_numeric($action_id));
        $kk = NULL;
        foreach ($this->qq as $k => $q) {
            if ($action_id == $q->get_id()) {
                $kk = $k;
                break;
            }
        }
        if ($kk === NULL) {
            return FALSE;
        }
        if (!$this->qq[$kk]->match_username($username)) {
            throw new exception ('Not allowed', ERR_ACCESS_DENIED);
        }
        $item = $this->qq[$kk];
        if($delete_db === TRUE) {
            $status = QUEUE_CANCELLED;
            update_queue_status($db, $item->get_dbid(), $status);
        }
        unset($this->qq[$kk]);
        $this->update_all_download_position($db);
        return TRUE;
    }


    function pause(DatabaseConnection $db, $action_id, $do_pause, $username)// $do_pause == true then pause, else continue (unpause)
    {
        assert(is_bool($do_pause) && is_numeric($action_id));
        $status = $do_pause ? QUEUE_PAUSED : QUEUE_QUEUED;
        foreach ($this->qq as $q) {
            if ($action_id == $q->get_id()) {
                $rv = $q->pause($do_pause, $username);
                $cmd = $q->get_command();
                update_queue_status ($db, $q->get_dbid(), $status, NULL, NULL, NULL, $do_pause);
                if (compare_command($cmd, urdd_protocol::COMMAND_DOWNLOAD) ||compare_command($cmd, urdd_protocol::COMMAND_DOWNLOAD_ACTION)) { 
                    $dlid = $q->get_args();
                    update_dlinfo_status($db, $do_pause ? DOWNLOAD_PAUSED : DOWNLOAD_QUEUED, $dlid);
                }
                return TRUE;
            }
        }
        throw new exception ('Item not found', ERR_ITEM_NOT_FOUND);
    }


    function pause_cmd(DatabaseConnection $db, $cmd, $arg, $do_pause, $username)// $do_pause == true then pause, else continue (unpause)
    {
        assert(is_bool($do_pause));
        $cnt = 0;
        $status = $do_pause ? QUEUE_PAUSED : QUEUE_QUEUED;
        foreach ($this->qq as $q) {
            if ($q->is_equal($cmd, $arg)) {
                try {
                    $rv = $q->pause($do_pause, $username);
                    $cnt++;
                    update_queue_status ($db, $q->get_dbid(), $status, NULL, NULL, NULL, $do_pause);
                    if (compare_command($cmd, urdd_protocol::COMMAND_DOWNLOAD) ||compare_command($cmd, urdd_protocol::COMMAND_DOWNLOAD_ACTION)) { 
                        $dlid = $q->get_args();
                        update_dlinfo_status($db, $do_pause ? DOWNLOAD_PAUSED : DOWNLOAD_QUEUED, $dlid);
                    }

                } catch (exception $e) {
                    ;
                }
            }
        }
        if ($cnt == 0) {
            throw new exception ('item not found',ERR_ITEM_NOT_FOUND);
        }
    }


    function pause_all(DatabaseConnection $db, $do_pause, $username)// $do_pause == true then pause, else continue (unpause)
    {
        assert(is_bool($do_pause));
        $status = $do_pause ? QUEUE_PAUSED : QUEUE_QUEUED;
        foreach ($this->qq as $q) {
            try {
                $q->pause($do_pause, $username);
                $cmd = $q->get_command();
                update_queue_status ($db, $q->get_dbid(), $status, NULL, NULL, NULL, $do_pause);
                if (compare_command($cmd, urdd_protocol::COMMAND_DOWNLOAD) ||compare_command($cmd, urdd_protocol::COMMAND_DOWNLOAD_ACTION)) { 
                    $dlid = $q->get_args();
                    update_dlinfo_status($db, $do_pause ? DOWNLOAD_PAUSED : DOWNLOAD_QUEUED, $dlid);
                }

            } catch (exception $e) {
                ;
            }
        }
    }


    protected function add_prio(action $item, DatabaseConnection $db, $increase_counter=TRUE)
    {
        assert(is_bool($increase_counter));
        if (($this->max_size > 0) && ($this->size() >= $this->max_size)) {
            throw new exception ('Queue full', ERR_QUEUE_FULL);
        }
        if ($item->max_exceeded(self::MAX_REQUEUE_COUNT)) {
            $status = QUEUE_CANCELLED;
            update_queue_status($db, $item->get_dbid(), $status);
            write_log('Item queued too often, task cancelled: ' . "{$item->get_command()} {$item->get_args()}", LOG_NOTICE);
            return FALSE;
        }
        $item->inc_counter();
        if ($increase_counter === TRUE) { // false if we cancel a thread and push it back to the queue
            echo_debug('pushing on the queue', DEBUG_SERVER);
            $status = QUEUE_QUEUED;
            //$dir = $item->get_dlpath();
            $dbid = insert_queue_status($db, $item->get_id(), "{$item->get_command()} {$item->get_args()}", $status, $item->get_command_code(), $item->get_username(), 0, '', $item->get_priority());
            if ($dbid !== FALSE) {
                $item->set_dbid($dbid);
                echo_debug("Pushing on the queue $dbid", DEBUG_SERVER);
            } else {
                throw new exception_queue_failed('Queueing failed');
            }
        } else {
            $dbid = $item->get_dbid();
        }

        $prio = $item->get_priority();
        $status = $item->is_paused() ? QUEUE_PAUSED : QUEUE_QUEUED;
        update_queue_status ($db, $dbid, $status, NULL, NULL, NULL, $item->is_paused());
        
        $temp_ql = $temp_qm = array();
        foreach ($this->qq as $q) {
            if ($q->get_priority() <= $prio) {
                $temp_ql[] = $q;
            } else {
                $temp_qm[] = $q;
            }
        }
        $temp_ql[] = $item;
        $this->qq = array_merge($temp_ql, $temp_qm);
        $this->update_all_download_position($db);
        return $dbid;
    }


    function top($mayhave_nntp=TRUE, array $not_these=array(), $mayhave_db_intensive= TRUE)
    {
        assert(is_bool($mayhave_nntp));
        if ($this->is_empty()) {
            return FALSE;
        }
        if ($mayhave_nntp === TRUE) {
            $first = NULL;
            foreach ($this->qq as $q) {
                if ($q->is_paused() === FALSE) {
                    if (in_array($q->get_id(), $not_these)) {
                        continue; // skip the ones we already tried
                    }
                    if ($mayhave_db_intensive === FALSE && $q->db_intensive()) {
                        continue; // skip, if it is a db intensive job and we may not start one
                    }
                    if ($q->need_nntp() === TRUE) { // find the first with a nntp connection
                        return $q;
                    } elseif ($first === NULL) {
                        $first = $q;
                    }
                }
            }
            return (($first !== NULL) ? $first : FALSE);
        } else {
            foreach ($this->qq as $q) {
                if (($q->need_nntp() === FALSE) && ($q->is_paused() === FALSE) && ($mayhave_db_intensive === TRUE || $q->db_intensive() === FALSE)) {
                    return $q;
                }
            }
        }
        return FALSE;
    }


    function set_priority(DatabaseConnection $db, $action_id, $username, $priority)
    {
        return $this->set_priorities($db, array($action_id), $username, $priority);
    }


    function set_priorities(DatabaseConnection $db, array $action_ids, $username, $priority)
    { 
        assert(is_numeric($priority));
        $kk = array();
        foreach ($this->qq as $k => $q) {
            if (in_array($q->get_id(), $action_ids)) {
                $q->set_priority($priority, $username);
                update_queue_priority($db, $q->get_dbid(), $priority);
                $kk[] = $k;
            }
        }
        if ($kk === array()) {
            throw new exception('Item not found', ERR_ITEM_NOT_FOUND);
        }
        usort($this->qq, array('queue', 'prio_sort'));
        $this->update_all_download_position($db);
        return TRUE;
    }

    static private function prio_sort($a, $b)
    {
        $p1 = $a->get_priority();
        $p2 = $b->get_priority();

        return (($p1 == $p2) ? 0 : ($p1 < $p2 ? -1 : 1));
    }

} //queue


