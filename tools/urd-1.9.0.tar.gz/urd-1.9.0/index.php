<?php

/*
 *  This file is part of Urd.
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2013-08-04 00:07:36 +0200 (zo, 04 aug 2013) $
 * $Rev: 2885 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: index.php 2885 2013-08-03 22:07:36Z gavinspearhead@gmail.com $
 */

// If not installed, go to install.php, otherwise go to the normal index page:
if (!file_exists('.installed')) {
    header('Location: install/install.php');
} else {
    header('Location: html/index.php');
}
