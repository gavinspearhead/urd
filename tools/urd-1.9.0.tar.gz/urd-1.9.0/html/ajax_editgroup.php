<?php
/*
 *  This file is part of Urd.
 *  vim:ts=4:expandtab:cindent
 *
 *  Urd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *  Urd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. See the file "COPYING". If it does not
 *  exist, see <http://www.gnu.org/licenses/>.
 *
 * $LastChangedDate: 2013-09-02 23:20:45 +0200 (ma, 02 sep 2013) $
 * $Rev: 2909 $
 * $Author: gavinspearhead@gmail.com $
 * $Id: ajax_editgroup.php 2909 2013-09-02 21:20:45Z gavinspearhead@gmail.com $
 */
define('ORIGINAL_PAGE', $_SERVER['PHP_SELF']);
$__auth = 'silent';

$pathaet = realpath(dirname(__FILE__));
require_once "$pathaet/../functions/html_includes.php";
require_once "$pathaet/../functions/periods.php";

verify_access($db, urd_modules::URD_CLASS_GROUPS, TRUE, '', $userid, TRUE);

$cmd = get_request('cmd', '');
$id = get_request('id', '');

$db->escape($cmd);

$prefs = load_config($db);

function showeditgroup(DatabaseConnection $db, $id)
{
    global $LN, $smarty, $periods;
    // Get download info:
    if (is_numeric($id)) {
        $db->escape($id);
        $sql = "SELECT * FROM groups WHERE \"id\" = '$id'";
        $res = $db->execute_query($sql);
        if (!isset($res[0])) {
            throw new exception($LN['error_invalidgroupid']);
        }
        $row = $res[0];
        $oldname = $row['name'];
        $oldadult = ($row['adult'] == ADULT_ON) ? 1 : 0;
        $oldsubscribed = $row['active'];
        $oldexpire = $row['expire'];

        $oldminsetsize = $row['minsetsize'] === NULL ? 0 : $row['minsetsize'];
        list($val, $suf) = format_size($oldminsetsize, 'h', '');
        $oldminsetsize =  $val . $suf;
        $oldmaxsetsize = $row['maxsetsize'] === NULL ? 0 : $row['maxsetsize'];
        list($val, $suf) = format_size($oldmaxsetsize, 'h', '');
        $oldmaxsetsize =  $val . $suf;
        $oldrefresh_time = $row['refresh_time'];
        $oldrefresh_period = $row['refresh_period'];

        if ($oldrefresh_period > 0) {
            $oldtime1 = floor($oldrefresh_time / 60);
            $oldtime2 = floor($oldrefresh_time % 60);
        } else {
            $oldtime1 = $oldtime2 = NULL;
        }
    } elseif ($id == 'new') {
        $oldname = $oldurl = $oldpassword = $oldusername = '';
        $oldexpire = get_config($db, 'default_expire_time');
        $oldadult = 0;
        $oldsubscribed = NG_SUBSCRIBED;
        $oldmaxsetsize = $oldminsetsize = 0;
        $time1 = $time2 = NULL;
        $oldrefresh_time = '';
    } else {
        throw new exception($LN['error_invalidfeedid']);
    }

    list($pkeys, $ptexts) = $periods->get_periods();
    init_smarty('', 0);
    $smarty->assign('id',		        $id);
    $smarty->assign('oldname',	        $oldname);
    $smarty->assign('oldminsetsize',	$oldminsetsize);
    $smarty->assign('oldmaxsetsize',	$oldmaxsetsize);
    $smarty->assign('oldadult',	        $oldadult);
    $smarty->assign('oldtime1',	        $oldtime1);
    $smarty->assign('oldtime2',	        $oldtime2);
    $smarty->assign('periods_texts',	$ptexts);
    $smarty->assign('periods_keys',		$pkeys);
    $smarty->assign('oldrefresh',       $oldrefresh_period);
    $smarty->assign('oldsubscribed',	$oldsubscribed);
    $smarty->assign('oldexpire',	    $oldexpire);
    $smarty->display('ajax_editgroup.tpl');
    die();
}

function update_group_info(DatabaseConnection $db, $id, $userid)
{
    global $LN, $smarty, $periods;
    // Actually rename the download
    challenge::verify_challenge_text($_POST['challenge']);
    $newurl = trim(get_post('group_url'));
    $username = trim(get_post('group_username'));
    $time1 = trim(get_post('group_time1'));
    $time2 = trim(get_post('group_time2'));
    $refresh_period = trim(get_post('group_refresh_period'));
    $password = trim(get_post('group_password'));
    $newexpire = trim(get_post('group_expire'));

    if (!is_numeric($newexpire)) {
        throw new exception($LN['error_notanumber']. ': ' . $LN['ng_expire_time'] . ' ' . htmlentities($newexpire));
    }
    $newadult = trim(get_post('group_adult', '0') == '1') ?  ADULT_ON : ADULT_OFF;
    $newsubscribed = (get_post('group_subscribed', '0') == '1') ? NG_SUBSCRIBED : NG_UNSUBSCRIBED;
    $uprefs = load_config($db);
    $uc = new urdd_client($db, $uprefs['urdd_host'], $uprefs['urdd_port'], $userid);
    $newminsetsize = trim(get_post('group_minsetsize'));
    $newmaxsetsize = trim(get_post('group_maxsetsize'));
    try {
        $newminsetsize = unformat_size($newminsetsize, 1024, 'm');
        $newmaxsetsize = unformat_size($newmaxsetsize, 1024, 'm');
    } catch (exception $e) {
        throw new exception($LN['error_invalidvalue'] . ' ' . $e->getMessage());
    }
    if ($newmaxsetsize < $newminsetsize) {
        throw new exception($LN['error_invalidvalue'] );
    }

    if ($newsubscribed == NG_UNSUBSCRIBED) {
        $db->escape($id);
        $sql = "UPDATE rss_urls SET \"refresh_time\"='0', \"refresh_period\"='0' WHERE \"id\"=$id";
        $db->execute_query($sql);

        $uc->cancel(get_command(urdd_protocol::COMMAND_UPDATE) . " $id");
        $uc->cancel(get_command(urdd_protocol::COMMAND_EXPIRE) . " $id");
        $uc->unsubscribe($id, USERSETTYPE_GROUP);
        remove_schedule($db, $uc, $id, urdd_protocol::COMMAND_UPDATE);
    } else {
        $uc->subscribe($id, $newexpire, $newminsetsize, $newmaxsetsize);
        $period = $periods->get($refresh_period);
        if ($period === FALSE) {
            throw new exception($LN['error_invalidupdatevalue']);
        }

        remove_schedule($db, $uc, $id, urdd_protocol::COMMAND_UPDATE);
        if ($period->get_interval() !== NULL) {
            if (!is_numeric($time1)) {
                throw new exception($LN['error_notanumber']);
            }
            if (!is_numeric($time2)) {
                throw new exception($LN['error_notanumber']);
            }
            if ($time1 > 23 || $time1 < 0) {
                throw new exception($LN['error_toomanydays']);
            }
            if ($time2 > 59 || $time1 < 0) {
                throw new exception($LN['error_toomanymins']);
            }

            // Sanity checks:
            $time1 %= 24;
            $time2 %= 60;
            $time = $time1 * 60 + $time2; // Used to display the update time, is in mins after 0:00
            $nicetime = $time1 . ':' . $time2;
            // if we have a proper schedule set it here

            set_period($uc, $db, $id, $nicetime, $period->get_interval(), $time, $period->get_id());
                if (is_numeric($id)) {
                    update_group_state($db, $id, $newsubscribed, $newexpire, $newminsetsize, $newmaxsetsize, $newadult);
                } else {
                    throw new exception($LN['error_invalidgroupid']);
                }
        }
    }
}

switch (strtolower($cmd)) {
case 'showeditgroup':
    showeditgroup($db, $id);
    break;
case 'update_group':
    update_group_info($db, $id, $userid);
    break;
default:
    throw new exception($LN['error_invalidaction']);
    break;
}

// Success:
die_html('OK');
